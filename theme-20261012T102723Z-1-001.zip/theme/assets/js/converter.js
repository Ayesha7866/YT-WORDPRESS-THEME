/**
 * YTMP4 - Frontend Converter Controller (API-Ready)
 * 
 * Provides interactive validation, format selection, progress states, 
 * result rendering, and hookable events for future backend API/plugin integration.
 */

(function () {
  'use strict';

  // Config and DOM selectors
  const selectors = {
    form: '#ytmp4-converter-form',
    input: '#ytmp4-url-input',
    convertBtn: '#ytmp4-convert-btn',
    pasteBtn: '#ytmp4-paste-btn',
    clearBtn: '#ytmp4-clear-btn',
    tabs: '.ytmp4-tab-btn',
    qualitySelect: '#ytmp4-quality-select',
    statusArea: '#ytmp4-status-area',
    statusText: '#ytmp4-status-text',
    progressFill: '#ytmp4-progress-fill',
    resultArea: '#ytmp4-result-area',
    resultThumb: '#ytmp4-result-thumb',
    resultTitle: '#ytmp4-result-title',
    resultAuthor: '#ytmp4-result-author',
    resultDuration: '#ytmp4-result-duration',
    resetBtn: '#ytmp4-reset-btn',
    errorBox: '#ytmp4-error-box',
    downloadsBody: '#ytmp4-downloads-body'
  };

  class YTMP4Converter {
    constructor() {
      this.form = document.querySelector(selectors.form);
      if (!this.form) return;

      this.input = document.querySelector(selectors.input);
      this.convertBtn = document.querySelector(selectors.convertBtn);
      this.pasteBtn = document.querySelector(selectors.pasteBtn);
      this.clearBtn = document.querySelector(selectors.clearBtn);
      this.tabs = document.querySelectorAll(selectors.tabs);
      this.qualitySelect = document.querySelector(selectors.qualitySelect);
      this.statusArea = document.querySelector(selectors.statusArea);
      this.statusText = document.querySelector(selectors.statusText);
      this.progressFill = document.querySelector(selectors.progressFill);
      this.resultArea = document.querySelector(selectors.resultArea);
      this.resultThumb = document.querySelector(selectors.resultThumb);
      this.resultTitle = document.querySelector(selectors.resultTitle);
      this.resultAuthor = document.querySelector(selectors.resultAuthor);
      this.resultDuration = document.querySelector(selectors.resultDuration);
      this.resetBtn = document.querySelector(selectors.resetBtn);
      this.errorBox = document.querySelector(selectors.errorBox);
      this.downloadsBody = document.querySelector(selectors.downloadsBody);

      this.currentFormat = 'mp4';
      this.currentQuality = '1080p';
      this.isConverting = false;

      this.initEvents();
    }

    initEvents() {
      // Form submit
      this.form.addEventListener('submit', (e) => {
        e.preventDefault();
        this.handleConvert();
      });

      // Tabs click
      this.tabs.forEach((tab) => {
        tab.addEventListener('click', () => {
          this.tabs.forEach((t) => t.classList.remove('active'));
          tab.classList.add('active');
          this.currentFormat = tab.getAttribute('data-format') || 'mp4';
          this.updateQualityOptions();
        });
      });

      // Quality selector change
      if (this.qualitySelect) {
        this.qualitySelect.addEventListener('change', (e) => {
          this.currentQuality = e.target.value;
        });
      }

      // Paste button
      if (this.pasteBtn) {
        this.pasteBtn.addEventListener('click', async () => {
          try {
            if (navigator.clipboard && navigator.clipboard.readText) {
              const text = await navigator.clipboard.readText();
              if (text) {
                this.input.value = text.trim();
                this.validateInput();
              }
            }
          } catch (err) {
            console.warn('Clipboard read permission denied:', err);
          }
        });
      }

      // Clear button
      if (this.clearBtn) {
        this.clearBtn.addEventListener('click', () => {
          this.input.value = '';
          this.input.focus();
          this.clearError();
        });
      }

      // Reset button (Convert another)
      if (this.resetBtn) {
        this.resetBtn.addEventListener('click', () => {
          this.resetConverter();
        });
      }

      // Input changes
      if (this.input) {
        this.input.addEventListener('input', () => {
          this.clearError();
        });
      }
    }

    extractVideoId(url) {
      if (!url) return null;
      // Regex supporting watch?v=, youtu.be/, shorts/, embed/
      const regex = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/|youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/;
      const match = url.match(regex);
      return match ? match[1] : null;
    }

    validateInput() {
      const url = this.input.value.trim();
      if (!url) {
        this.showError('Please paste a YouTube video link to start conversion.');
        return false;
      }

      const videoId = this.extractVideoId(url);
      if (!videoId) {
        this.showError('Invalid YouTube URL. Please enter a valid YouTube video, shorts, or playlist link.');
        return false;
      }

      this.clearError();
      return { url, videoId };
    }

    showError(msg) {
      if (this.errorBox) {
        this.errorBox.textContent = msg;
        this.errorBox.style.display = 'block';
      } else {
        alert(msg);
      }
    }

    clearError() {
      if (this.errorBox) {
        this.errorBox.textContent = '';
        this.errorBox.style.display = 'none';
      }
    }

    updateQualityOptions() {
      if (!this.qualitySelect) return;
      if (this.currentFormat === 'mp3') {
        this.qualitySelect.innerHTML = `
          <option value="320kbps">320 kbps (High Quality)</option>
          <option value="256kbps">256 kbps (Standard)</option>
          <option value="192kbps">192 kbps</option>
          <option value="128kbps">128 kbps (Compact)</option>
        `;
      } else if (this.currentFormat === 'shorts') {
        this.qualitySelect.innerHTML = `
          <option value="1080p">1080p HD (Shorts)</option>
          <option value="720p">720p HD</option>
        `;
      } else {
        this.qualitySelect.innerHTML = `
          <option value="1080p">1080p Full HD (MP4)</option>
          <option value="720p">720p HD (MP4)</option>
          <option value="480p">480p (MP4)</option>
          <option value="360p">360p (MP4)</option>
        `;
      }
    }

    async handleConvert() {
      if (this.isConverting) return;
      const valid = this.validateInput();
      if (!valid) return;

      this.isConverting = true;
      this.convertBtn.disabled = true;
      this.clearError();

      // Dispatch custom hook for external API scripts / WordPress plugins
      const eventDetail = {
        url: valid.url,
        videoId: valid.videoId,
        format: this.currentFormat,
        quality: this.qualitySelect ? this.qualitySelect.value : '1080p'
      };
      
      document.dispatchEvent(new CustomEvent('ytmp4:convert_start', { detail: eventDetail }));

      // Check if WordPress AJAX or custom REST API is available
      const apiConfig = window.ytmp4_api_config || null;
      if (apiConfig && apiConfig.use_real_api && apiConfig.ajax_url) {
        this.processRealApi(apiConfig, eventDetail);
      } else {
        // Fallback frontend preview simulation
        this.simulateConversion(valid.videoId, eventDetail);
      }
    }

    async processRealApi(config, params) {
      this.showStatus('Connecting to conversion server...', 15);
      try {
        const formData = new FormData();
        formData.append('action', 'ytmp4_convert_video');
        formData.append('nonce', config.nonce || '');
        formData.append('url', params.url);
        formData.append('format', params.format);
        formData.append('quality', params.quality);

        const response = await fetch(config.ajax_url, {
          method: 'POST',
          body: formData
        });

        const data = await response.json();
        if (data.success && data.data) {
          this.renderResult(data.data);
        } else {
          throw new Error(data.data && data.data.message ? data.data.message : 'Conversion failed on server.');
        }
      } catch (err) {
        this.showError(err.message || 'Error communicating with converter service.');
        this.resetState();
      }
    }

    simulateConversion(videoId, params) {
      // Realistic multi-stage UI preview
      this.showStatus('Fetching YouTube video metadata...', 20);

      setTimeout(() => {
        this.showStatus('Analyzing available audio and video streams...', 50);

        setTimeout(() => {
          this.showStatus('Encoding and preparing download packages...', 85);

          setTimeout(() => {
            this.showStatus('Completed!', 100);

            const mockResult = {
              videoId: videoId,
              title: 'YouTube High Definition Video (' + (params.format.toUpperCase()) + ')',
              author: 'Official YouTube Channel',
              duration: '04:28',
              thumbnail: `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`,
              format: params.format,
              downloads: [
                { quality: '1080p Full HD', format: 'MP4', size: '64.2 MB', url: '#' },
                { quality: '720p HD', format: 'MP4', size: '38.1 MB', url: '#' },
                { quality: '480p Medium', format: 'MP4', size: '21.5 MB', url: '#' },
                { quality: '360p Standard', format: 'MP4', size: '14.0 MB', url: '#' },
                { quality: '320kbps Audio', format: 'MP3', size: '9.8 MB', url: '#' }
              ]
            };

            this.renderResult(mockResult);
            document.dispatchEvent(new CustomEvent('ytmp4:convert_complete', { detail: mockResult }));
          }, 600);
        }, 600);
      }, 600);
    }

    showStatus(text, percent) {
      if (this.statusArea) {
        this.statusArea.classList.add('active');
        if (this.statusText) this.statusText.textContent = text;
        if (this.progressFill) this.progressFill.style.width = percent + '%';
      }
    }

    renderResult(data) {
      if (this.statusArea) {
        this.statusArea.classList.remove('active');
      }

      if (this.resultThumb) {
        this.resultThumb.src = data.thumbnail || `https://img.youtube.com/vi/${data.videoId}/hqdefault.jpg`;
        this.resultThumb.alt = data.title;
      }
      if (this.resultTitle) this.resultTitle.textContent = data.title;
      if (this.resultAuthor) this.resultAuthor.textContent = data.author || 'YouTube Video';
      if (this.resultDuration) this.resultDuration.textContent = data.duration || '03:45';

      if (this.downloadsBody) {
        this.downloadsBody.innerHTML = '';
        data.downloads.forEach((item) => {
          const row = document.createElement('tr');
          row.innerHTML = `
            <td><strong>${item.quality}</strong></td>
            <td><span class="ytmp4-badge-pill" style="padding: 2px 10px; font-size: 0.75rem;">${item.format}</span></td>
            <td>${item.size}</td>
            <td>
              <a href="${item.url}" class="ytmp4-download-btn" data-quality="${item.quality}" download>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                Download
              </a>
            </td>
          `;
          this.downloadsBody.appendChild(row);
        });
      }

      if (this.resultArea) {
        this.resultArea.classList.add('active');
      }

      this.resetState();
    }

    resetState() {
      this.isConverting = false;
      if (this.convertBtn) this.convertBtn.disabled = false;
    }

    resetConverter() {
      if (this.resultArea) this.resultArea.classList.remove('active');
      if (this.statusArea) this.statusArea.classList.remove('active');
      if (this.input) {
        this.input.value = '';
        this.input.focus();
      }
      this.clearError();
      this.resetState();
    }
  }

  // Initialize on DOM ready
  document.addEventListener('DOMContentLoaded', () => {
    window.ytmp4Converter = new YTMP4Converter();
  });
})();
