/**
 * YTMP4 - Main Frontend UI Script
 */

(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    // 1. Header scroll effect
    const header = document.querySelector('.ytmp4-header');
    if (header) {
      window.addEventListener('scroll', () => {
        if (window.scrollY > 20) {
          header.classList.add('scrolled');
        } else {
          header.classList.remove('scrolled');
        }
      });
    }

    // 2. Mobile Menu Toggle
    const mobileToggle = document.querySelector('.ytmp4-mobile-toggle');
    const mobileDrawer = document.querySelector('.ytmp4-mobile-drawer');
    if (mobileToggle && mobileDrawer) {
      mobileToggle.addEventListener('click', function () {
        const isOpen = mobileDrawer.classList.toggle('open');
        mobileToggle.setAttribute('aria-expanded', isOpen);
      });
    }

    // 3. FAQ Accordion
    const faqItems = document.querySelectorAll('.ytmp4-faq-item');
    faqItems.forEach((item) => {
      const questionBtn = item.querySelector('.ytmp4-faq-question');
      const answer = item.querySelector('.ytmp4-faq-answer');
      if (questionBtn && answer) {
        questionBtn.addEventListener('click', () => {
          const isActive = item.classList.contains('active');

          // Close all other items for clean single-accordion behavior
          faqItems.forEach((other) => {
            other.classList.remove('active');
            const otherBtn = other.querySelector('.ytmp4-faq-question');
            const otherAns = other.querySelector('.ytmp4-faq-answer');
            if (otherAns) otherAns.style.maxHeight = null;
            if (otherBtn) otherBtn.setAttribute('aria-expanded', 'false');
          });

          if (!isActive) {
            item.classList.add('active');
            questionBtn.setAttribute('aria-expanded', 'true');
            answer.style.maxHeight = answer.scrollHeight + 'px';
          }
        });
      }
    });

    // Open first FAQ item by default if exists
    if (faqItems.length > 0) {
      const firstItem = faqItems[0];
      const firstBtn = firstItem.querySelector('.ytmp4-faq-question');
      const firstAns = firstItem.querySelector('.ytmp4-faq-answer');
      if (firstItem && firstAns) {
        firstItem.classList.add('active');
        if (firstBtn) firstBtn.setAttribute('aria-expanded', 'true');
        firstAns.style.maxHeight = firstAns.scrollHeight + 'px';
      }
    }

    // 4. Smooth Anchor Scrolling
    document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
      anchor.addEventListener('click', function (e) {
        const targetId = this.getAttribute('href');
        if (targetId && targetId !== '#') {
          const targetElem = document.querySelector(targetId);
          if (targetElem) {
            e.preventDefault();
            targetElem.scrollIntoView({ behavior: 'smooth' });
          }
        }
      });
    });
  });
})();
