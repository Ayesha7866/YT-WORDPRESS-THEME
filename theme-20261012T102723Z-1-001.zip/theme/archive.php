<?php
/**
 * YTMP4 - Archive Template
 *
 * @package YTMP4
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<div class="ytmp4-archive-header" style="background:#ffffff; border-bottom:1px solid #e2e8f0; padding:48px 0 32px; text-align:center;">
    <div class="ytmp4-container">
        <?php ytmp4_breadcrumbs(); ?>
        <h1 class="ytmp4-hero-title">
            <?php the_archive_title(); ?>
        </h1>
        <?php if (get_the_archive_description()) : ?>
            <p class="ytmp4-hero-subtitle"><?php the_archive_description(); ?></p>
        <?php endif; ?>
    </div>
</div>

<div class="ytmp4-archive-body" style="padding: 56px 0;">
    <div class="ytmp4-container">
        <?php if (have_posts()) : ?>
            <div class="ytmp4-tools-grid">
                <?php while (have_posts()) : the_post(); ?>
                    <article class="ytmp4-tool-card">
                        <span class="ytmp4-tool-badge"><?php echo esc_html(get_post_type()); ?></span>
                        <h2 class="ytmp4-tool-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                        <div class="ytmp4-tool-desc"><?php the_excerpt(); ?></div>
                        <a href="<?php the_permalink(); ?>" class="ytmp4-tool-link-text">
                            <?php esc_html_e('Read Article', 'ytmp4'); ?> →
                        </a>
                    </article>
                <?php endwhile; ?>
            </div>

            <div style="margin-top: 40px; text-align:center;">
                <?php the_posts_pagination(); ?>
            </div>
        <?php else : ?>
            <p style="text-align:center; color:#64748b;"><?php esc_html_e('No articles found in this archive.', 'ytmp4'); ?></p>
        <?php endif; ?>
    </div>
</div>

<?php
get_footer();
