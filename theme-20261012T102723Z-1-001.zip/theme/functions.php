<?php
/**
 * YTMP4 - Theme Functions & Definitions
 *
 * @package YTMP4
 */

if (!defined('ABSPATH')) {
    exit;
}

define('YTMP4_VERSION', '1.0.0');

/**
 * Sets up theme defaults and registers support for various WordPress features.
 */
function ytmp4_setup() {
    // Add default posts and comments RSS feed links to head.
    add_theme_support('automatic-feed-links');

    // Let WordPress manage the document title.
    add_theme_support('title-tag');

    // Enable support for Post Thumbnails on posts and pages.
    add_theme_support('post-thumbnails');

    // Register navigation menus.
    register_nav_menus(array(
        'primary' => esc_html__('Primary Menu', 'ytmp4'),
        'footer'  => esc_html__('Footer Menu', 'ytmp4'),
    ));

    // Switch default core markup to output valid HTML5.
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ));

    // Custom Logo Support
    add_theme_support('custom-logo', array(
        'height'      => 90,
        'width'       => 420,
        'flex-width'  => true,
        'flex-height' => true,
    ));

    // Elementor and Gutenberg Support
    add_theme_support('align-wide');
    add_theme_support('responsive-embeds');
    add_theme_support('editor-styles');
    add_theme_support('elementor');
}
add_action('after_setup_theme', 'ytmp4_setup');

/**
 * Enqueue scripts and styles.
 */
function ytmp4_scripts() {
    // Main Theme Stylesheet
    wp_enqueue_style(
        'ytmp4-main-style',
        get_template_directory_uri() . '/assets/css/main.css',
        array(),
        YTMP4_VERSION
    );

    // Root style.css
    wp_enqueue_style(
        'ytmp4-style',
        get_stylesheet_uri(),
        array('ytmp4-main-style'),
        YTMP4_VERSION
    );

    // Converter Component Script (API-Ready)
    wp_enqueue_script(
        'ytmp4-converter',
        get_template_directory_uri() . '/assets/js/converter.js',
        array(),
        YTMP4_VERSION,
        true
    );

    // Main Interactive UI Script
    wp_enqueue_script(
        'ytmp4-main',
        get_template_directory_uri() . '/assets/js/main.js',
        array('ytmp4-converter'),
        YTMP4_VERSION,
        true
    );

    // Localize Script for API & AJAX integration
    wp_localize_script('ytmp4-converter', 'ytmp4_api_config', array(
        'ajax_url'     => admin_url('admin-ajax.php'),
        'rest_url'     => esc_url_raw(rest_url('ytmp4/v1/convert')),
        'nonce'        => wp_create_nonce('ytmp4_converter_nonce'),
        'use_real_api' => (bool) get_theme_mod('ytmp4_enable_real_api', false),
    ));
}
add_action('wp_enqueue_scripts', 'ytmp4_scripts');

/**
 * Fallback Navigation Menu
 *
 * Ensures seamless display of standard converter links before a menu is created.
 */
function ytmp4_fallback_menu() {
    $menu_items = array(
        esc_html__('Home', 'ytmp4')              => home_url('/'),
        esc_html__('YouTube MP4', 'ytmp4')       => home_url('/youtube-to-mp4/'),
        esc_html__('YouTube MP3', 'ytmp4')       => home_url('/youtube-to-mp3/'),
        esc_html__('Shorts Downloader', 'ytmp4') => home_url('/youtube-shorts-downloader/'),
        esc_html__('FAQ', 'ytmp4')               => home_url('/faq/'),
        esc_html__('Contact', 'ytmp4')           => home_url('/contact/'),
    );

    echo '<ul class="ytmp4-nav-menu">';
    foreach ($menu_items as $title => $url) {
        $active_class = (is_front_page() && $url === home_url('/')) ? ' current-menu-item' : '';
        echo '<li class="' . esc_attr($active_class) . '"><a href="' . esc_url($url) . '">' . esc_html($title) . '</a></li>';
    }
    echo '</ul>';
}

/**
 * On Theme Activation: Run One-time Setup for Demo Pages and Menus
 */
function ytmp4_theme_activation_action() {
    if (function_exists('ytmp4_create_all_seo_pages')) {
        ytmp4_create_all_seo_pages();
    }
    if (function_exists('ytmp4_setup_default_menus')) {
        ytmp4_setup_default_menus();
    }
}
add_action('after_switch_theme', 'ytmp4_theme_activation_action');

/**
 * Include Sub-modules and Extensions
 */
require_once get_template_directory() . '/inc/seo-schema.php';
require_once get_template_directory() . '/inc/api-handlers.php';
require_once get_template_directory() . '/inc/customizer.php';
require_once get_template_directory() . '/inc/demo-pages.php';
require_once get_template_directory() . '/inc/elementor/elementor-init.php';
