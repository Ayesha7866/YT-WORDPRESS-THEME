<?php
/**
 * YTMP4 - Header Template
 *
 * @package YTMP4
 */

if (!defined('ABSPATH')) {
    exit;
}
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    
    <!-- Bundled Favicon Fallback -->
    <?php if (!has_site_icon()) : ?>
        <link rel="icon" type="image/svg+xml" href="<?php echo esc_url(get_template_directory_uri() . '/assets/images/favicon.svg'); ?>">
        <link rel="icon" type="image/png" href="<?php echo esc_url(get_template_directory_uri() . '/assets/images/favicon.png'); ?>">
    <?php endif; ?>

    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="ytmp4-header" id="site-header">
    <div class="ytmp4-container">
        <div class="ytmp4-nav-wrapper">
            <!-- Brand Logo -->
            <div class="ytmp4-logo-area">
                <?php if (has_custom_logo()) : ?>
                    <?php the_custom_logo(); ?>
                <?php else : ?>
                    <a href="<?php echo esc_url(home_url('/')); ?>" class="ytmp4-logo-link" rel="home">
                        <img 
                            src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/logo.svg'); ?>" 
                            alt="<?php echo esc_attr(get_bloginfo('name', 'display')); ?> - YouTube to MP4 Converter" 
                            class="ytmp4-logo-img"
                            width="210"
                            height="45"
                        />
                    </a>
                <?php endif; ?>
            </div>

            <!-- Primary Navigation Menu -->
            <nav class="ytmp4-nav" aria-label="<?php esc_attr_e('Main Navigation', 'ytmp4'); ?>">
                <?php
                if (has_nav_menu('primary')) {
                    wp_nav_menu(array(
                        'theme_location' => 'primary',
                        'menu_class'     => 'ytmp4-nav-menu',
                        'container'      => false,
                        'depth'          => 2,
                        'fallback_cb'    => 'ytmp4_fallback_menu',
                    ));
                } else {
                    ytmp4_fallback_menu();
                }
                ?>
            </nav>

            <!-- Header CTA Button & Mobile Toggle -->
            <div class="ytmp4-nav-actions">
                <?php 
                $cta_text = get_theme_mod('ytmp4_header_cta_text', __('Convert Now', 'ytmp4'));
                $cta_link = get_theme_mod('ytmp4_header_cta_link', '#converter');
                ?>
                <a href="<?php echo esc_url($cta_link); ?>" class="ytmp4-btn-primary">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                    <span><?php echo esc_html($cta_text); ?></span>
                </a>

                <button class="ytmp4-mobile-toggle" aria-label="<?php esc_attr_e('Toggle navigation menu', 'ytmp4'); ?>" aria-expanded="false">
                    ☰
                </button>
            </div>
        </div>
    </div>

    <!-- Mobile Drawer Menu -->
    <div class="ytmp4-mobile-drawer">
        <?php
        if (has_nav_menu('primary')) {
            wp_nav_menu(array(
                'theme_location' => 'primary',
                'container'      => false,
                'depth'          => 1,
                'fallback_cb'    => 'ytmp4_fallback_menu',
            ));
        } else {
            ytmp4_fallback_menu();
        }
        ?>
        <div style="margin-top: 16px;">
            <a href="<?php echo esc_url($cta_link); ?>" class="ytmp4-btn-primary" style="width: 100%;">
                <?php echo esc_html($cta_text); ?>
            </a>
        </div>
    </div>
</header>
<main id="primary" class="site-main">
