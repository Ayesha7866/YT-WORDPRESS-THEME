<?php
/**
 * YTMP4 - Feature Cards Section Template Part
 *
 * @package YTMP4
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<section class="ytmp4-features-section" id="features">
    <div class="ytmp4-container">
        <div class="ytmp4-section-header">
            <h2 class="ytmp4-section-title"><?php esc_html_e('Why Use Our YouTube Converter?', 'ytmp4'); ?></h2>
            <p class="ytmp4-section-desc"><?php esc_html_e('Engineered for lightning speed, original video clarity, and smooth cross-device compatibility.', 'ytmp4'); ?></p>
        </div>

        <div class="ytmp4-features-grid">
            <!-- 1. Fast Conversion -->
            <div class="ytmp4-feature-card">
                <div class="ytmp4-feature-icon-box">
                    <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
                </div>
                <h3 class="ytmp4-feature-title"><?php esc_html_e('Fast Conversion', 'ytmp4'); ?></h3>
                <p class="ytmp4-feature-text"><?php esc_html_e('Blazing-fast cloud conversion servers process your YouTube video links in just a few seconds without waiting queues.', 'ytmp4'); ?></p>
            </div>

            <!-- 2. HD Video Quality -->
            <div class="ytmp4-feature-card">
                <div class="ytmp4-feature-icon-box">
                    <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>
                </div>
                <h3 class="ytmp4-feature-title"><?php esc_html_e('HD Video Quality', 'ytmp4'); ?></h3>
                <p class="ytmp4-feature-text"><?php esc_html_e('Download videos in uncompressed quality up to 1080p Full HD, 2K, and 4K Ultra HD resolution with high-fidelity audio.', 'ytmp4'); ?></p>
            </div>

            <!-- 3. Mobile Friendly -->
            <div class="ytmp4-feature-card">
                <div class="ytmp4-feature-icon-box">
                    <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg>
                </div>
                <h3 class="ytmp4-feature-title"><?php esc_html_e('Mobile Friendly', 'ytmp4'); ?></h3>
                <p class="ytmp4-feature-text"><?php esc_html_e('Flawlessly responsive on smartphones, tablets, Android Chrome, and iPhone Safari without installing extra apps.', 'ytmp4'); ?></p>
            </div>

            <!-- 4. Easy To Use -->
            <div class="ytmp4-feature-card">
                <div class="ytmp4-feature-icon-box">
                    <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 14 14"/></svg>
                </div>
                <h3 class="ytmp4-feature-title"><?php esc_html_e('Easy To Use', 'ytmp4'); ?></h3>
                <p class="ytmp4-feature-text"><?php esc_html_e('Simple 3-step workflow: paste URL, select video quality, and tap download. No signups, accounts, or surveys required.', 'ytmp4'); ?></p>
            </div>
        </div>
    </div>
</section>
