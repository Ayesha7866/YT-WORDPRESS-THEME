<?php
/**
 * YTMP4 - Hero Section Template Part
 *
 * @package YTMP4
 */

if (!defined('ABSPATH')) {
    exit;
}

$hero_h1 = get_post_meta(get_the_ID(), 'ytmp4_custom_h1', true);
if (empty($hero_h1)) {
    $hero_h1 = __('YouTube to MP4 Converter', 'ytmp4');
}

$hero_sub = get_post_meta(get_the_ID(), 'ytmp4_custom_subtitle', true);
if (empty($hero_sub)) {
    $hero_sub = __('Convert YouTube videos to MP4 format quickly with a simple, fast and mobile-friendly online converter.', 'ytmp4');
}
?>
<section class="ytmp4-hero-section">
    <div class="ytmp4-container">
        <div class="ytmp4-hero-content">
            <div class="ytmp4-badge-pill">
                <span>●</span> <?php esc_html_e('Fast & Free Online Converter', 'ytmp4'); ?>
            </div>
            
            <h1 class="ytmp4-hero-title">
                <?php echo esc_html($hero_h1); ?>
            </h1>
            
            <p class="ytmp4-hero-subtitle">
                <?php echo esc_html($hero_sub); ?>
            </p>
        </div>

        <!-- Render the Converter Box -->
        <?php get_template_part('template-parts/converter-box'); ?>

        <!-- Trust Features Checklist -->
        <div class="ytmp4-hero-trust-row">
            <div class="ytmp4-trust-item"><span class="ytmp4-trust-icon">✓</span> <?php esc_html_e('100% Free & Unlimited', 'ytmp4'); ?></div>
            <div class="ytmp4-trust-item"><span class="ytmp4-trust-icon">✓</span> <?php esc_html_e('Up to 4K Ultra HD', 'ytmp4'); ?></div>
            <div class="ytmp4-trust-item"><span class="ytmp4-trust-icon">✓</span> <?php esc_html_e('No Software Required', 'ytmp4'); ?></div>
            <div class="ytmp4-trust-item"><span class="ytmp4-trust-icon">✓</span> <?php esc_html_e('Instant Processing', 'ytmp4'); ?></div>
        </div>
    </div>
</section>
