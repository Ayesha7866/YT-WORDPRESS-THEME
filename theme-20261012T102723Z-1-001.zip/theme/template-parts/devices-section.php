<?php
/**
 * YTMP4 - Device Compatibility Section Template Part
 *
 * @package YTMP4
 */

if (!defined('ABSPATH')) {
    exit;
}

$devices = array(
    array(
        'title' => esc_html__('Desktop PC & Mac', 'ytmp4'),
        'desc'  => esc_html__('Supports Chrome, Edge, Safari, Firefox, and Opera on Windows, macOS, and Linux.', 'ytmp4'),
        'icon'  => '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>'
    ),
    array(
        'title' => esc_html__('Android Smartphones', 'ytmp4'),
        'desc'  => esc_html__('Works smoothly on Samsung, Google Pixel, Xiaomi, and all Android devices directly in Chrome.', 'ytmp4'),
        'icon'  => '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg>'
    ),
    array(
        'title' => esc_html__('iPhone & iPad (iOS)', 'ytmp4'),
        'desc'  => esc_html__('Download directly to Safari Files or Camera Roll on iOS 13+ without needing Documents by Readdle.', 'ytmp4'),
        'icon'  => '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="2" width="16" height="20" rx="2" ry="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg>'
    ),
    array(
        'title' => esc_html__('Tablets & Chromebooks', 'ytmp4'),
        'desc'  => esc_html__('Fully responsive touch interface optimized for Android tablets, iPadOS, and Chromebooks.', 'ytmp4'),
        'icon'  => '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="2" width="16" height="20" rx="2" ry="2"/><circle cx="12" cy="18" r="1"/></svg>'
    ),
);
?>
<section class="ytmp4-devices-section" id="compatibility">
    <div class="ytmp4-container">
        <div class="ytmp4-section-header">
            <h2 class="ytmp4-section-title"><?php esc_html_e('Cross-Device Compatibility', 'ytmp4'); ?></h2>
            <p class="ytmp4-section-desc"><?php esc_html_e('Convert and download your media seamlessly on any operating system without installing extra software.', 'ytmp4'); ?></p>
        </div>

        <div class="ytmp4-devices-grid">
            <?php foreach ($devices as $dev) : ?>
                <div class="ytmp4-device-card">
                    <div class="ytmp4-device-icon" style="color: var(--ytmp4-primary); display:flex; justify-content:center;">
                        <?php echo $dev['icon']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                    </div>
                    <h3 class="ytmp4-device-title"><?php echo esc_html($dev['title']); ?></h3>
                    <p class="ytmp4-device-desc"><?php echo esc_html($dev['desc']); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
