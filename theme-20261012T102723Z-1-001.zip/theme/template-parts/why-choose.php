<?php
/**
 * YTMP4 - Why Choose YTMP4 Section Template Part
 *
 * @package YTMP4
 */

if (!defined('ABSPATH')) {
    exit;
}

$reasons = array(
    array(
        'title' => esc_html__('Simple Interface', 'ytmp4'),
        'desc'  => esc_html__('Clean, distraction-free interface without annoying popups or confusing multi-page redirects.', 'ytmp4')
    ),
    array(
        'title' => esc_html__('Fast Processing', 'ytmp4'),
        'desc'  => esc_html__('Cutting-edge high bitrate cloud nodes extract and re-encode streams in fractions of a second.', 'ytmp4')
    ),
    array(
        'title' => esc_html__('Works On All Devices', 'ytmp4'),
        'desc'  => esc_html__('Fully compatible with mobile, tablet, and desktop without requiring browser add-ons or extensions.', 'ytmp4')
    ),
    array(
        'title' => esc_html__('Easy Conversion Process', 'ytmp4'),
        'desc'  => esc_html__('Intuitive copy-paste workflow allows anyone to save videos in their favorite format effortlessly.', 'ytmp4')
    ),
);
?>
<section class="ytmp4-why-section" id="why-choose">
    <div class="ytmp4-container">
        <div class="ytmp4-section-header">
            <h2 class="ytmp4-section-title"><?php esc_html_e('Why Choose YTMP4?', 'ytmp4'); ?></h2>
            <p class="ytmp4-section-desc"><?php esc_html_e('Thousands of users trust YTMP4 everyday for fast, safe, and dependable video downloads.', 'ytmp4'); ?></p>
        </div>

        <div class="ytmp4-why-grid">
            <?php foreach ($reasons as $reason) : ?>
                <div class="ytmp4-why-card">
                    <span class="ytmp4-why-check">✓</span>
                    <h3 class="ytmp4-why-title"><?php echo esc_html($reason['title']); ?></h3>
                    <p class="ytmp4-why-desc"><?php echo esc_html($reason['desc']); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
