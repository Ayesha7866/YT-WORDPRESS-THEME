<?php
/**
 * YTMP4 - How It Works Section Template Part
 *
 * @package YTMP4
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<section class="ytmp4-how-section" id="how-it-works">
    <div class="ytmp4-container">
        <div class="ytmp4-section-header">
            <h2 class="ytmp4-section-title"><?php esc_html_e('How It Works', 'ytmp4'); ?></h2>
            <p class="ytmp4-section-desc"><?php esc_html_e('Convert your favorite YouTube videos into MP4 in 3 simple steps.', 'ytmp4'); ?></p>
        </div>

        <div class="ytmp4-steps-grid">
            <!-- Step 1 -->
            <div class="ytmp4-step-card">
                <div class="ytmp4-step-number">1</div>
                <h3 class="ytmp4-step-title"><?php esc_html_e('Step 1: Paste YouTube URL', 'ytmp4'); ?></h3>
                <p class="ytmp4-step-text"><?php esc_html_e('Copy the video, shorts, or clip link from YouTube and paste it into the converter search bar above.', 'ytmp4'); ?></p>
            </div>

            <!-- Step 2 -->
            <div class="ytmp4-step-card">
                <div class="ytmp4-step-number">2</div>
                <h3 class="ytmp4-step-title"><?php esc_html_e('Step 2: Choose Format', 'ytmp4'); ?></h3>
                <p class="ytmp4-step-text"><?php esc_html_e('Select your desired video resolution (1080p, 720p, 480p) or extract MP3 audio and click "Convert Now".', 'ytmp4'); ?></p>
            </div>

            <!-- Step 3 -->
            <div class="ytmp4-step-card">
                <div class="ytmp4-step-number">3</div>
                <h3 class="ytmp4-step-title"><?php esc_html_e('Step 3: Download File', 'ytmp4'); ?></h3>
                <p class="ytmp4-step-text"><?php esc_html_e('Once conversion completes within moments, click "Download" to save the file straight to your device.', 'ytmp4'); ?></p>
            </div>
        </div>
    </div>
</section>
