<?php
/**
 * YTMP4 - FAQ Accordion Section Template Part
 *
 * @package YTMP4
 */

if (!defined('ABSPATH')) {
    exit;
}

$faqs = ytmp4_get_default_faqs();
?>
<section class="ytmp4-faq-section" id="faq">
    <div class="ytmp4-container">
        <div class="ytmp4-section-header">
            <h2 class="ytmp4-section-title"><?php esc_html_e('Frequently Asked Questions', 'ytmp4'); ?></h2>
            <p class="ytmp4-section-desc"><?php esc_html_e('Everything you need to know about video conversion, supported formats, and audio quality.', 'ytmp4'); ?></p>
        </div>

        <div class="ytmp4-faq-list">
            <?php foreach ($faqs as $index => $item) : ?>
                <div class="ytmp4-faq-item <?php echo 0 === $index ? 'active' : ''; ?>">
                    <button type="button" class="ytmp4-faq-question" aria-expanded="<?php echo 0 === $index ? 'true' : 'false'; ?>">
                        <span><?php echo esc_html($item['q']); ?></span>
                        <span class="ytmp4-faq-toggle-icon">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"/></svg>
                        </span>
                    </button>
                    <div class="ytmp4-faq-answer">
                        <div class="ytmp4-faq-answer-inner">
                            <?php echo esc_html($item['a']); ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
