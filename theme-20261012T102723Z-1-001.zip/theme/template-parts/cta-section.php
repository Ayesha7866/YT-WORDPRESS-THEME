<?php
/**
 * YTMP4 - CTA Section Template Part
 *
 * @package YTMP4
 */

if (!defined('ABSPATH')) {
    exit;
}

$cta_title    = get_theme_mod('ytmp4_cta_title', __('Ready to Convert YouTube Videos to MP4?', 'ytmp4'));
$cta_desc     = get_theme_mod('ytmp4_cta_desc', __('Enjoy unlimited, ultra-fast, and free conversions in crystal-clear 1080p Full HD and 4K today.', 'ytmp4'));
$cta_btn_text = get_theme_mod('ytmp4_cta_btn_text', __('Start Converting Now — Free', 'ytmp4'));
$cta_btn_link = get_theme_mod('ytmp4_cta_btn_link', '#converter');
?>
<section class="ytmp4-cta-section">
    <div class="ytmp4-container">
        <div class="ytmp4-cta-banner">
            <h2 class="ytmp4-cta-title"><?php echo esc_html($cta_title); ?></h2>
            <p class="ytmp4-cta-desc"><?php echo esc_html($cta_desc); ?></p>
            <a href="<?php echo esc_url($cta_btn_link); ?>" class="ytmp4-btn-cta">
                <span><?php echo esc_html($cta_btn_text); ?></span>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg>
            </a>
        </div>
    </div>
</section>
