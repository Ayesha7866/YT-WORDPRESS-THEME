<?php
/**
 * YTMP4 - Front Page Template (Homepage)
 *
 * Renders all 9 required homepage sections, with complete Elementor visual
 * editing support.
 *
 * @package YTMP4
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();

// Check if page was designed via Elementor
$is_elementor_page = false;
if (did_action('elementor/loaded') && \Elementor\Plugin::$instance->documents->get(get_the_ID())) {
    $document = \Elementor\Plugin::$instance->documents->get(get_the_ID());
    if ($document && $document->is_built_with_elementor()) {
        $is_elementor_page = true;
    }
}

if ($is_elementor_page) :
    // Render Elementor Content
    while (have_posts()) :
        the_post();
        the_content();
    endwhile;
else :
    // Render the 9 Turnkey Production Sections:

    // SECTION 2: Hero Section & Converter Box
    get_template_part('template-parts/hero-section');

    // SECTION 3: Feature Cards (Fast Conversion, HD Quality, Mobile Friendly, Easy to Use)
    get_template_part('template-parts/features-section');

    // SECTION 4: How It Works (Step 1, Step 2, Step 3)
    get_template_part('template-parts/how-it-works');

    // SECTION 5: Popular Tools (MP4, MP3, Shorts, Thumbnail, Playlist)
    get_template_part('template-parts/tools-section');

    // SECTION 6: Why Choose YTMP4 (Trust section)
    get_template_part('template-parts/why-choose');

    // SECTION 7: Device Compatibility (Desktop, Android, iPhone, Tablet)
    get_template_part('template-parts/devices-section');

    // SECTION 8: FAQ Accordion
    get_template_part('template-parts/faq-section');

    // SECTION 9: Call to Action (CTA) Section
    get_template_part('template-parts/cta-section');

endif;

get_footer();
