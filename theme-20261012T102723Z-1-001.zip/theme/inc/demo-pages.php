<?php
/**
 * YTMP4 - 1-Click SEO Landing Pages & Menu Generator
 *
 * Automatically provisions all 19 required SEO landing pages,
 * setting the correct slugs, page templates, meta titles, and navigation menus.
 *
 * @package YTMP4
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register Admin Submenu
 */
function ytmp4_register_admin_menu() {
    add_theme_page(
        __('YTMP4 SEO Pages Setup', 'ytmp4'),
        __('YTMP4 SEO Pages', 'ytmp4'),
        'manage_options',
        'ytmp4-setup-pages',
        'ytmp4_render_admin_setup_page'
    );
}
add_action('admin_menu', 'ytmp4_register_admin_menu');

/**
 * Render Admin Setup Page
 */
function ytmp4_render_admin_setup_page() {
    if (isset($_POST['ytmp4_generate_pages']) && check_admin_referer('ytmp4_generate_pages_action')) {
        $created_count = ytmp4_create_all_seo_pages();
        ytmp4_setup_default_menus();
        echo '<div class="notice notice-success is-dismissible"><p><strong>' . esc_html(sprintf(__('Successfully generated %d SEO landing pages and assigned navigation menus!', 'ytmp4'), $created_count)) . '</strong></p></div>';
    }

    $pages_list = ytmp4_get_required_seo_pages();
    ?>
    <div class="wrap" style="max-width: 960px;">
        <h1 style="display:flex; align-items:center; gap:12px;">
            <span style="background:#2563eb; color:#fff; padding:6px 14px; border-radius:8px; font-size:18px;">YTMP4</span>
            <?php esc_html_e('1-Click SEO Landing Pages Generator', 'ytmp4'); ?>
        </h1>
        <p style="font-size: 15px; color:#475569;">
            <?php esc_html_e('Instantly create all 19 required production-ready SEO landing pages and setup WordPress navigation menus with zero broken links.', 'ytmp4'); ?>
        </p>

        <div style="background:#fff; border:1px solid #cbd5e1; border-radius:12px; padding:24px; margin-top:20px; box-shadow:0 4px 6px -1px rgba(0,0,0,0.05);">
            <form method="post">
                <?php wp_nonce_field('ytmp4_generate_pages_action'); ?>
                <p>
                    <input type="submit" name="ytmp4_generate_pages" class="button button-primary button-hero" value="<?php esc_attr_e('Generate All 19 SEO Landing Pages & Menus', 'ytmp4'); ?>" style="background:#2563eb; border-color:#1d4ed8; font-weight:700;">
                </p>
            </form>

            <h3 style="margin-top:30px;"><?php esc_html_e('Configured SEO Landing Pages (19 Pages):', 'ytmp4'); ?></h3>
            <table class="widefat fixed striped" style="margin-top:12px;">
                <thead>
                    <tr>
                        <th style="width: 40px;">#</th>
                        <th><?php esc_html_e('Page Title', 'ytmp4'); ?></th>
                        <th><?php esc_html_e('Target Slug (URL)', 'ytmp4'); ?></th>
                        <th><?php esc_html_e('Current Status', 'ytmp4'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $i = 1;
                    foreach ($pages_list as $slug => $data) : 
                        $existing = get_page_by_path($slug);
                    ?>
                    <tr>
                        <td><strong><?php echo esc_html($i++); ?></strong></td>
                        <td><strong><?php echo esc_html($data['title']); ?></strong></td>
                        <td><code>/<?php echo esc_html($slug); ?>/</code></td>
                        <td>
                            <?php if ($existing) : ?>
                                <span style="color:#16a34a; font-weight:bold;">✓ <?php esc_html_e('Created', 'ytmp4'); ?></span> 
                                (<a href="<?php echo esc_url(get_permalink($existing->ID)); ?>" target="_blank"><?php esc_html_e('View', 'ytmp4'); ?></a> | 
                                 <a href="<?php echo esc_url(get_edit_post_link($existing->ID)); ?>"><?php esc_html_e('Edit', 'ytmp4'); ?></a>)
                            <?php else : ?>
                                <span style="color:#94a3b8;"><?php esc_html_e('Pending Generation', 'ytmp4'); ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
}

/**
 * Return All 19 Required SEO Pages Definition
 */
function ytmp4_get_required_seo_pages() {
    return array(
        'youtube-to-mp4' => array(
            'title'     => 'YouTube To MP4 Converter',
            'h1'        => 'YouTube to MP4 Converter - Download High Quality MP4 Videos',
            'subtitle'  => 'Convert and download YouTube videos to MP4 format quickly in 1080p, 720p, 480p, and 4K resolution.',
            'format'    => 'mp4',
            'template'  => 'template-landing-page.php',
        ),
        'convert-youtube-to-mp4' => array(
            'title'     => 'Convert YouTube To MP4',
            'h1'        => 'Convert YouTube Videos to MP4 Online',
            'subtitle'  => 'The fastest way to convert YouTube videos into crystal-clear MP4 files ready for offline viewing on any device.',
            'format'    => 'mp4',
            'template'  => 'template-landing-page.php',
        ),
        'youtube-video-converter' => array(
            'title'     => 'YouTube Video Converter',
            'h1'        => 'YouTube Video Converter - Free Online Video Downloader',
            'subtitle'  => 'All-in-one YouTube video converter supporting high-speed MP4 video and MP3 audio downloads without registration.',
            'format'    => 'mp4',
            'template'  => 'template-landing-page.php',
        ),
        'youtube-to-mp3' => array(
            'title'     => 'YouTube MP3 Converter',
            'h1'        => 'YouTube to MP3 Converter - Free High Quality Audio Extractor',
            'subtitle'  => 'Extract crystal-clear 320kbps MP3 audio tracks directly from your favorite YouTube videos with one click.',
            'format'    => 'mp3',
            'template'  => 'template-landing-page.php',
        ),
        'youtube-shorts-downloader' => array(
            'title'     => 'YouTube Shorts Downloader',
            'h1'        => 'YouTube Shorts Downloader - Save Vertical Videos in Full HD',
            'subtitle'  => 'Download YouTube Shorts videos in high resolution MP4 format directly to your phone or PC with zero watermarks.',
            'format'    => 'shorts',
            'template'  => 'template-landing-page.php',
        ),
        'youtube-thumbnail-downloader' => array(
            'title'     => 'YouTube Thumbnail Downloader',
            'h1'        => 'YouTube Thumbnail Downloader - High Definition Images',
            'subtitle'  => 'Grab high-res, Full HD 1080p, and 4K YouTube cover thumbnails instantly from any video or Shorts link.',
            'format'    => 'thumbnail',
            'template'  => 'template-landing-page.php',
        ),
        'youtube-playlist-downloader' => array(
            'title'     => 'YouTube Playlist Downloader',
            'h1'        => 'YouTube Playlist Downloader - Download Full Video Playlists',
            'subtitle'  => 'Batch download entire YouTube playlists or series to MP4 and MP3 format smoothly and effortlessly.',
            'format'    => 'playlist',
            'template'  => 'template-landing-page.php',
        ),
        'youtube-to-mp4-1080p' => array(
            'title'     => 'YouTube To MP4 1080p',
            'h1'        => 'YouTube to MP4 1080p Full HD Converter',
            'subtitle'  => 'Download YouTube videos in crisp 1080p Full High Definition with clear audio and vibrant visuals.',
            'format'    => 'mp4',
            'template'  => 'template-landing-page.php',
        ),
        'youtube-to-mp4-hd' => array(
            'title'     => 'YouTube To MP4 HD',
            'h1'        => 'YouTube to MP4 HD Converter - High Bitrate Video Downloads',
            'subtitle'  => 'Save YouTube videos in standard 720p and 1080p High Definition format optimized for modern screens.',
            'format'    => 'mp4',
            'template'  => 'template-landing-page.php',
        ),
        'youtube-to-mp4-4k' => array(
            'title'     => 'YouTube To MP4 4K',
            'h1'        => 'YouTube to MP4 4K Ultra HD Converter',
            'subtitle'  => 'Preserve every detail with 4K (2160p) Ultra HD YouTube video conversions at 60 FPS without compression loss.',
            'format'    => 'mp4',
            'template'  => 'template-landing-page.php',
        ),
        'youtube-to-mp4-android' => array(
            'title'     => 'YouTube To MP4 Android',
            'h1'        => 'YouTube to MP4 for Android - Mobile Video Downloader',
            'subtitle'  => 'Convert and save YouTube videos directly to your Android gallery using Chrome, Firefox, or Samsung Internet.',
            'format'    => 'mp4',
            'template'  => 'template-landing-page.php',
        ),
        'youtube-to-mp4-iphone' => array(
            'title'     => 'YouTube To MP4 iPhone',
            'h1'        => 'YouTube to MP4 for iPhone & iPad (iOS)',
            'subtitle'  => 'Easily download YouTube videos to your iPhone Camera Roll or Files app using Safari without extra apps.',
            'format'    => 'mp4',
            'template'  => 'template-landing-page.php',
        ),
        'how-it-works' => array(
            'title'     => 'How It Works',
            'h1'        => 'How It Works - Simple 3-Step YouTube Conversion',
            'subtitle'  => 'Learn how YTMP4 converts video links into downloaded MP4 files in three intuitive steps.',
            'format'    => 'mp4',
            'template'  => 'template-landing-page.php',
        ),
        'faq' => array(
            'title'     => 'Frequently Asked Questions',
            'h1'        => 'Frequently Asked Questions (FAQ)',
            'subtitle'  => 'Everything you need to know about video conversion, compatibility, limits, and file quality.',
            'format'    => 'mp4',
            'template'  => 'template-landing-page.php',
        ),
        'contact' => array(
            'title'     => 'Contact Us',
            'h1'        => 'Contact the YTMP4 Support Team',
            'subtitle'  => 'Have questions, bug reports, or feature suggestions? Reach out to our technical team.',
            'format'    => 'mp4',
            'template'  => 'page.php',
        ),
        'privacy-policy' => array(
            'title'     => 'Privacy Policy',
            'h1'        => 'YTMP4 Privacy Policy',
            'subtitle'  => 'How we safeguard your privacy, handle temporary files, and respect user data.',
            'format'    => 'mp4',
            'template'  => 'page.php',
        ),
        'terms-of-service' => array(
            'title'     => 'Terms Of Service',
            'h1'        => 'YTMP4 Terms of Service',
            'subtitle'  => 'Terms and conditions governing the use of YTMP4 online video conversion utility.',
            'format'    => 'mp4',
            'template'  => 'page.php',
        ),
        'dmca' => array(
            'title'     => 'DMCA Policy',
            'h1'        => 'Digital Millennium Copyright Act (DMCA) Notice',
            'subtitle'  => 'Our strict copyright policy, compliance standards, and takedown notice procedures.',
            'format'    => 'mp4',
            'template'  => 'page.php',
        )
    );
}

/**
 * Programmatically Insert/Update All Pages
 */
function ytmp4_create_all_seo_pages() {
    $pages = ytmp4_get_required_seo_pages();
    $created = 0;

    foreach ($pages as $slug => $data) {
        $existing = get_page_by_path($slug);
        
        $page_args = array(
            'post_title'    => wp_strip_all_tags($data['title']),
            'post_name'     => $slug,
            'post_status'   => 'publish',
            'post_type'     => 'page',
            'post_content'  => ytmp4_get_sample_page_content($slug, $data),
            'page_template' => $data['template']
        );

        if ($existing) {
            $page_id = $existing->ID;
            update_post_meta($page_id, '_wp_page_template', $data['template']);
        } else {
            $page_id = wp_insert_post($page_args);
            if (!is_wp_error($page_id) && $page_id > 0) {
                $created++;
            }
        }

        if ($page_id > 0) {
            update_post_meta($page_id, 'ytmp4_custom_h1', $data['h1']);
            update_post_meta($page_id, 'ytmp4_custom_subtitle', $data['subtitle']);
            update_post_meta($page_id, 'ytmp4_target_format', $data['format']);
        }
    }

    return $created;
}

/**
 * Helper to generate in-depth SEO content for landing pages
 */
function ytmp4_get_sample_page_content($slug, $data) {
    ob_start();
    ?>
    <section class="ytmp4-page-body-content">
        <h2>Why Choose YTMP4 for <?php echo esc_html($data['title']); ?>?</h2>
        <p>
            When you want to convert videos quickly and securely, <strong>YTMP4</strong> provides an industry-leading cloud conversion engine. Our tool is optimized to deliver the highest possible bitrate and crystal-clear resolution without requiring invasive desktop software, browser extensions, or user registrations.
        </p>

        <h3>Key Advantages of Our Tool</h3>
        <ul>
            <li><strong>Zero Waiting Time:</strong> Instant stream extraction with direct high-speed cloud download pipes.</li>
            <li><strong>Cross-Platform Freedom:</strong> Flawless performance on Windows, macOS, Android smartphones, iPhones, and Linux.</li>
            <li><strong>Strict Privacy:</strong> We do not store your download logs, user IP addresses, or personal information.</li>
            <li><strong>Full Resolution Support:</strong> Convert in 360p, 480p, 720p HD, 1080p Full HD, and ultra-crisp 4K UHD.</li>
        </ul>

        <h2>Step-by-Step Conversion Guide</h2>
        <ol>
            <li><strong>Copy the Video URL:</strong> Open YouTube on your browser or app, locate your video, and copy its link.</li>
            <li><strong>Paste into Converter:</strong> Paste the copied link into the input field above and choose your quality preset.</li>
            <li><strong>Click Convert:</strong> Tap the "Convert Now" button. Within moments, your download links will appear ready for saving.</li>
        </ol>

        <h2>Frequently Asked Questions</h2>
        <p>
            <strong>Is it free?</strong> Absolutely. YTMP4 is completely free and requires no subscription fees or payment information.<br>
            <strong>Are downloads capped?</strong> No, you can convert as many clips, music tracks, and tutorial videos as you want.
        </p>
    </section>
    <?php
    return ob_get_clean();
}

/**
 * Setup Primary and Footer Menus
 */
function ytmp4_setup_default_menus() {
    $menu_name = 'YTMP4 Primary Menu';
    $menu_exists = wp_get_nav_menu_object($menu_name);

    if (!$menu_exists) {
        $menu_id = wp_create_nav_menu($menu_name);

        $items = array(
            'Home'               => home_url('/'),
            'YouTube MP4'        => home_url('/youtube-to-mp4/'),
            'YouTube MP3'        => home_url('/youtube-to-mp3/'),
            'Shorts Downloader'  => home_url('/youtube-shorts-downloader/'),
            'FAQ'                => home_url('/faq/'),
            'Contact'            => home_url('/contact/'),
        );

        foreach ($items as $title => $url) {
            wp_update_nav_menu_item($menu_id, 0, array(
                'menu-item-title'  => $title,
                'menu-item-url'    => $url,
                'menu-item-status' => 'publish',
            ));
        }

        $locations = get_theme_mod('nav_menu_locations');
        $locations['primary'] = $menu_id;
        set_theme_mod('nav_menu_locations', $locations);
    }
}
