<?php
/**
 * YTMP4 - Theme Customizer Integration
 *
 * @package YTMP4
 */

if (!defined('ABSPATH')) {
    exit;
}

function ytmp4_customize_register($wp_customize) {
    // 1. YTMP4 Brand Panel
    $wp_customize->add_section('ytmp4_theme_options', array(
        'title'    => __('YTMP4 Theme Settings', 'ytmp4'),
        'priority' => 30,
    ));

    // Primary Brand Color
    $wp_customize->add_setting('ytmp4_primary_color', array(
        'default'           => '#2563eb',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'ytmp4_primary_color', array(
        'label'    => __('Primary Brand Color', 'ytmp4'),
        'section'  => 'ytmp4_theme_options',
        'settings' => 'ytmp4_primary_color',
    )));

    // Accent Color
    $wp_customize->add_setting('ytmp4_accent_color', array(
        'default'           => '#06b6d4',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'ytmp4_accent_color', array(
        'label'    => __('Accent Color', 'ytmp4'),
        'section'  => 'ytmp4_theme_options',
        'settings' => 'ytmp4_accent_color',
    )));

    // Header CTA Button Text
    $wp_customize->add_setting('ytmp4_header_cta_text', array(
        'default'           => __('Convert Now', 'ytmp4'),
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('ytmp4_header_cta_text', array(
        'label'    => __('Header CTA Button Text', 'ytmp4'),
        'section'  => 'ytmp4_theme_options',
        'type'     => 'text',
    ));

    // Header CTA Link
    $wp_customize->add_setting('ytmp4_header_cta_link', array(
        'default'           => '#converter',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('ytmp4_header_cta_link', array(
        'label'    => __('Header CTA Link URL', 'ytmp4'),
        'section'  => 'ytmp4_theme_options',
        'type'     => 'text',
    ));

    // Footer Copyright Text
    $wp_customize->add_setting('ytmp4_footer_copyright', array(
        'default'           => sprintf(__('© %s YTMP4. All rights reserved. Ultra-fast video conversion tools.', 'ytmp4'), date('Y')),
        'sanitize_callback' => 'wp_kses_post',
    ));
    $wp_customize->add_control('ytmp4_footer_copyright', array(
        'label'    => __('Footer Copyright Text', 'ytmp4'),
        'section'  => 'ytmp4_theme_options',
        'type'     => 'textarea',
    ));

    // API Mode Toggle
    $wp_customize->add_setting('ytmp4_enable_real_api', array(
        'default'           => false,
        'sanitize_callback' => 'wp_validate_boolean',
    ));
    $wp_customize->add_control('ytmp4_enable_real_api', array(
        'label'       => __('Enable Live API Mode', 'ytmp4'),
        'description' => __('When checked, converter sends AJAX/REST calls to the registered backend hook rather than simulation.', 'ytmp4'),
        'section'     => 'ytmp4_theme_options',
        'type'        => 'checkbox',
    ));
}
add_action('customize_register', 'ytmp4_customize_register');

/**
 * Output Dynamic Customizer CSS
 */
function ytmp4_customizer_css() {
    $primary_color = get_theme_mod('ytmp4_primary_color', '#2563eb');
    $accent_color  = get_theme_mod('ytmp4_accent_color', '#06b6d4');

    if ($primary_color !== '#2563eb' || $accent_color !== '#06b6d4') {
        echo '<style id="ytmp4-customizer-css">';
        echo ':root {';
        echo '--ytmp4-primary: ' . esc_attr($primary_color) . ';';
        echo '--ytmp4-accent: ' . esc_attr($accent_color) . ';';
        echo '}';
        echo '</style>' . "\n";
    }
}
add_action('wp_head', 'ytmp4_customizer_css', 100);
