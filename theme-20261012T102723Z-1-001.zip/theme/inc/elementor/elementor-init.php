<?php
/**
 * YTMP4 - Elementor Compatibility & Widget Registration
 *
 * @package YTMP4
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register Elementor Category
 */
function ytmp4_register_elementor_category($elements_manager) {
    $elements_manager->add_category(
        'ytmp4-elements',
        array(
            'title' => esc_html__('YTMP4 Converter Elements', 'ytmp4'),
            'icon'  => 'eicon-video-camera',
        )
    );
}
add_action('elementor/elements/categories_registered', 'ytmp4_register_elementor_category');

/**
 * Register Elementor Custom Widgets
 */
function ytmp4_register_elementor_widgets($widgets_manager) {
    $widgets_dir = get_template_directory() . '/inc/elementor/widgets/';

    $widgets = array(
        'converter-widget.php'   => 'YTMP4_Converter_Widget',
        'features-widget.php'    => 'YTMP4_Features_Widget',
        'how-it-works-widget.php'=> 'YTMP4_HowItWorks_Widget',
        'tools-widget.php'       => 'YTMP4_Tools_Widget',
        'why-choose-widget.php'  => 'YTMP4_WhyChoose_Widget',
        'devices-widget.php'     => 'YTMP4_Devices_Widget',
        'faq-widget.php'         => 'YTMP4_FAQ_Widget',
        'cta-widget.php'         => 'YTMP4_CTA_Widget',
    );

    foreach ($widgets as $file => $class_name) {
        $file_path = $widgets_dir . $file;
        if (file_exists($file_path)) {
            require_once $file_path;
            if (class_exists($class_name)) {
                $widgets_manager->register(new $class_name());
            }
        }
    }
}
add_action('elementor/widgets/register', 'ytmp4_register_elementor_widgets');

/**
 * Support Elementor Full Width Page Templates
 */
function ytmp4_elementor_theme_support() {
    add_theme_support('elementor');
}
add_action('after_setup_theme', 'ytmp4_elementor_theme_support');
