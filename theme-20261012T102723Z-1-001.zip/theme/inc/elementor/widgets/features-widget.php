<?php
/**
 * YTMP4 - Elementor Feature Cards Widget
 *
 * @package YTMP4
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('\Elementor\Widget_Base')) {
    return;
}

class YTMP4_Features_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'ytmp4_features';
    }

    public function get_title() {
        return esc_html__('YTMP4 Feature Cards', 'ytmp4');
    }

    public function get_icon() {
        return 'eicon-star';
    }

    public function get_categories() {
        return array('ytmp4-elements');
    }

    protected function register_controls() {
        $this->start_controls_section(
            'section_features',
            array(
                'label' => esc_html__('Features Content', 'ytmp4'),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            )
        );

        $this->add_control(
            'section_title',
            array(
                'label'   => esc_html__('Section Title', 'ytmp4'),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Why Use Our YouTube Converter?', 'ytmp4'),
            )
        );

        $this->add_control(
            'section_desc',
            array(
                'label'   => esc_html__('Section Subtitle', 'ytmp4'),
                'type'    => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Engineered for lightning speed, original video clarity, and smooth cross-device compatibility.', 'ytmp4'),
            )
        );

        // Feature 1
        $this->add_control(
            'f1_title',
            array(
                'label'   => esc_html__('Card 1 Title', 'ytmp4'),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Fast Conversion', 'ytmp4'),
            )
        );
        $this->add_control(
            'f1_desc',
            array(
                'label'   => esc_html__('Card 1 Description', 'ytmp4'),
                'type'    => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Blazing-fast cloud conversion servers process your YouTube video links in just a few seconds.', 'ytmp4'),
            )
        );

        // Feature 2
        $this->add_control(
            'f2_title',
            array(
                'label'   => esc_html__('Card 2 Title', 'ytmp4'),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('HD Video Quality', 'ytmp4'),
            )
        );
        $this->add_control(
            'f2_desc',
            array(
                'label'   => esc_html__('Card 2 Description', 'ytmp4'),
                'type'    => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Download videos in uncompressed quality up to 1080p Full HD, 2K, and 4K Ultra HD resolution.', 'ytmp4'),
            )
        );

        // Feature 3
        $this->add_control(
            'f3_title',
            array(
                'label'   => esc_html__('Card 3 Title', 'ytmp4'),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Mobile Friendly', 'ytmp4'),
            )
        );
        $this->add_control(
            'f3_desc',
            array(
                'label'   => esc_html__('Card 3 Description', 'ytmp4'),
                'type'    => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Flawlessly responsive on smartphones, tablets, Android Chrome, and iPhone Safari.', 'ytmp4'),
            )
        );

        // Feature 4
        $this->add_control(
            'f4_title',
            array(
                'label'   => esc_html__('Card 4 Title', 'ytmp4'),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Easy To Use', 'ytmp4'),
            )
        );
        $this->add_control(
            'f4_desc',
            array(
                'label'   => esc_html__('Card 4 Description', 'ytmp4'),
                'type'    => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Simple 3-step workflow: paste URL, select video quality, and tap download. No signups required.', 'ytmp4'),
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $s = $this->get_settings_for_display();
        ?>
        <section class="ytmp4-features-section">
            <div class="ytmp4-container">
                <?php if (!empty($s['section_title'])) : ?>
                    <div class="ytmp4-section-header">
                        <h2 class="ytmp4-section-title"><?php echo esc_html($s['section_title']); ?></h2>
                        <?php if (!empty($s['section_desc'])) : ?>
                            <p class="ytmp4-section-desc"><?php echo esc_html($s['section_desc']); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <div class="ytmp4-features-grid">
                    <!-- Feature 1 -->
                    <div class="ytmp4-feature-card">
                        <div class="ytmp4-feature-icon-box">
                            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
                        </div>
                        <h3 class="ytmp4-feature-title"><?php echo esc_html($s['f1_title']); ?></h3>
                        <p class="ytmp4-feature-text"><?php echo esc_html($s['f1_desc']); ?></p>
                    </div>

                    <!-- Feature 2 -->
                    <div class="ytmp4-feature-card">
                        <div class="ytmp4-feature-icon-box">
                            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>
                        </div>
                        <h3 class="ytmp4-feature-title"><?php echo esc_html($s['f2_title']); ?></h3>
                        <p class="ytmp4-feature-text"><?php echo esc_html($s['f2_desc']); ?></p>
                    </div>

                    <!-- Feature 3 -->
                    <div class="ytmp4-feature-card">
                        <div class="ytmp4-feature-icon-box">
                            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg>
                        </div>
                        <h3 class="ytmp4-feature-title"><?php echo esc_html($s['f3_title']); ?></h3>
                        <p class="ytmp4-feature-text"><?php echo esc_html($s['f3_desc']); ?></p>
                    </div>

                    <!-- Feature 4 -->
                    <div class="ytmp4-feature-card">
                        <div class="ytmp4-feature-icon-box">
                            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 14 14"/></svg>
                        </div>
                        <h3 class="ytmp4-feature-title"><?php echo esc_html($s['f4_title']); ?></h3>
                        <p class="ytmp4-feature-text"><?php echo esc_html($s['f4_desc']); ?></p>
                    </div>
                </div>
            </div>
        </section>
        <?php
    }
}
