<?php
/**
 * YTMP4 - Elementor CTA Section Widget
 *
 * @package YTMP4
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('\Elementor\Widget_Base')) {
    return;
}

class YTMP4_CTA_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'ytmp4_cta';
    }

    public function get_title() {
        return esc_html__('YTMP4 Call to Action Banner', 'ytmp4');
    }

    public function get_icon() {
        return 'eicon-call-to-action';
    }

    public function get_categories() {
        return array('ytmp4-elements');
    }

    protected function register_controls() {
        $this->start_controls_section(
            'section_cta',
            array(
                'label' => esc_html__('CTA Content', 'ytmp4'),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            )
        );

        $this->add_control(
            'cta_title',
            array(
                'label'   => esc_html__('Title', 'ytmp4'),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Ready to Convert YouTube Videos to MP4?', 'ytmp4'),
            )
        );

        $this->add_control(
            'cta_desc',
            array(
                'label'   => esc_html__('Description', 'ytmp4'),
                'type'    => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Enjoy unlimited, ultra-fast, and free conversions in crystal-clear 1080p Full HD and 4K today.', 'ytmp4'),
            )
        );

        $this->add_control(
            'cta_btn_text',
            array(
                'label'   => esc_html__('Button Text', 'ytmp4'),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Start Converting Now — Free', 'ytmp4'),
            )
        );

        $this->add_control(
            'cta_btn_link',
            array(
                'label'   => esc_html__('Button Link URL', 'ytmp4'),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => '#converter',
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $s = $this->get_settings_for_display();
        ?>
        <section class="ytmp4-cta-section">
            <div class="ytmp4-container">
                <div class="ytmp4-cta-banner">
                    <h2 class="ytmp4-cta-title"><?php echo esc_html($s['cta_title']); ?></h2>
                    <p class="ytmp4-cta-desc"><?php echo esc_html($s['cta_desc']); ?></p>
                    <a href="<?php echo esc_url($s['cta_btn_link']); ?>" class="ytmp4-btn-cta">
                        <span><?php echo esc_html($s['cta_btn_text']); ?></span>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg>
                    </a>
                </div>
            </div>
        </section>
        <?php
    }
}
