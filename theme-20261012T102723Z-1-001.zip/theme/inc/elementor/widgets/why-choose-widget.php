<?php
/**
 * YTMP4 - Elementor Why Choose YTMP4 Widget
 *
 * @package YTMP4
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('\Elementor\Widget_Base')) {
    return;
}

class YTMP4_WhyChoose_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'ytmp4_why_choose';
    }

    public function get_title() {
        return esc_html__('YTMP4 Why Choose Us', 'ytmp4');
    }

    public function get_icon() {
        return 'eicon-shield-check';
    }

    public function get_categories() {
        return array('ytmp4-elements');
    }

    protected function register_controls() {
        $this->start_controls_section(
            'section_trust',
            array(
                'label' => esc_html__('Trust Content', 'ytmp4'),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            )
        );

        $this->add_control(
            'section_title',
            array(
                'label'   => esc_html__('Section Title', 'ytmp4'),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Why Choose YTMP4?', 'ytmp4'),
            )
        );

        $this->add_control(
            'section_desc',
            array(
                'label'   => esc_html__('Section Subtitle', 'ytmp4'),
                'type'    => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Thousands of users trust YTMP4 everyday for fast, safe, and dependable video downloads.', 'ytmp4'),
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $s = $this->get_settings_for_display();
        $reasons = array(
            array(
                'title' => esc_html__('Simple Interface', 'ytmp4'),
                'desc'  => esc_html__('Clean, distraction-free interface without annoying popups or confusing multi-page redirects.', 'ytmp4')
            ),
            array(
                'title' => esc_html__('Fast Processing', 'ytmp4'),
                'desc'  => esc_html__('Cutting-edge high bitrate cloud nodes extract and re-encode streams in fractions of a second.', 'ytmp4')
            ),
            array(
                'title' => esc_html__('Works On All Devices', 'ytmp4'),
                'desc'  => esc_html__('Fully compatible with mobile, tablet, and desktop without requiring browser add-ons or extensions.', 'ytmp4')
            ),
            array(
                'title' => esc_html__('Easy Conversion Process', 'ytmp4'),
                'desc'  => esc_html__('Intuitive copy-paste workflow allows anyone to save videos in their favorite format effortlessly.', 'ytmp4')
            ),
        );
        ?>
        <section class="ytmp4-why-section">
            <div class="ytmp4-container">
                <?php if (!empty($s['section_title'])) : ?>
                    <div class="ytmp4-section-header">
                        <h2 class="ytmp4-section-title"><?php echo esc_html($s['section_title']); ?></h2>
                        <?php if (!empty($s['section_desc'])) : ?>
                            <p class="ytmp4-section-desc"><?php echo esc_html($s['section_desc']); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <div class="ytmp4-why-grid">
                    <?php foreach ($reasons as $reason) : ?>
                        <div class="ytmp4-why-card">
                            <span class="ytmp4-why-check">✓</span>
                            <h3 class="ytmp4-why-title"><?php echo esc_html($reason['title']); ?></h3>
                            <p class="ytmp4-why-desc"><?php echo esc_html($reason['desc']); ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
        <?php
    }
}
