<?php
/**
 * YTMP4 - Elementor FAQ Accordion Widget
 *
 * @package YTMP4
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('\Elementor\Widget_Base')) {
    return;
}

class YTMP4_FAQ_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'ytmp4_faq';
    }

    public function get_title() {
        return esc_html__('YTMP4 FAQ Accordion', 'ytmp4');
    }

    public function get_icon() {
        return 'eicon-help-o';
    }

    public function get_categories() {
        return array('ytmp4-elements');
    }

    protected function register_controls() {
        $this->start_controls_section(
            'section_faq',
            array(
                'label' => esc_html__('FAQ Items', 'ytmp4'),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            )
        );

        $this->add_control(
            'section_title',
            array(
                'label'   => esc_html__('Section Title', 'ytmp4'),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Frequently Asked Questions', 'ytmp4'),
            )
        );

        $this->add_control(
            'section_desc',
            array(
                'label'   => esc_html__('Section Subtitle', 'ytmp4'),
                'type'    => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Everything you need to know about video conversion, supported formats, and audio quality.', 'ytmp4'),
            )
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'faq_question',
            array(
                'label'       => esc_html__('Question', 'ytmp4'),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__('What is YouTube to MP4 converter?', 'ytmp4'),
                'label_block' => true,
            )
        );

        $repeater->add_control(
            'faq_answer',
            array(
                'label'   => esc_html__('Answer', 'ytmp4'),
                'type'    => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('A YouTube to MP4 converter is an online tool that allows you to convert and download videos from YouTube into standard MP4 video files for offline viewing.', 'ytmp4'),
            )
        );

        $this->add_control(
            'faq_list',
            array(
                'label'       => esc_html__('FAQ Accordion List', 'ytmp4'),
                'type'        => \Elementor\Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'default'     => array(
                    array(
                        'faq_question' => esc_html__('What is YouTube to MP4 converter?', 'ytmp4'),
                        'faq_answer'   => esc_html__('A YouTube to MP4 converter is an online tool that allows you to convert and download videos from YouTube into standard MP4 video files. This enables you to store and watch your favorite video clips, tutorials, and music offline on any device without internet.', 'ytmp4'),
                    ),
                    array(
                        'faq_question' => esc_html__('How can I convert YouTube videos to MP4?', 'ytmp4'),
                        'faq_answer'   => esc_html__('Converting videos is simple with YTMP4: 1. Copy the URL of your chosen YouTube video. 2. Paste the URL into our input box above. 3. Select your desired MP4 quality (1080p, 720p, or 480p) and click "Convert Now". Once processed in seconds, click "Download" to save your file.', 'ytmp4'),
                    ),
                    array(
                        'faq_question' => esc_html__('Is this converter mobile friendly?', 'ytmp4'),
                        'faq_answer'   => esc_html__('Yes! YTMP4 is 100% responsive and mobile-optimized. You can use it smoothly on Android smartphones and tablets using Chrome or Firefox, as well as on iPhone and iPad running Safari with iOS 13+ without needing any third-party apps.', 'ytmp4'),
                    ),
                    array(
                        'faq_question' => esc_html__('Which formats are supported?', 'ytmp4'),
                        'faq_answer'   => esc_html__('YTMP4 supports multiple high-definition video and audio formats, including MP4 (360p, 480p, 720p HD, 1080p Full HD, 4K Ultra HD), MP3 audio (128kbps, 192kbps, 256kbps, 320kbps HQ), YouTube Shorts, and high-resolution thumbnail images.', 'ytmp4'),
                    ),
                ),
                'title_field' => '{{{ faq_question }}}',
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $s = $this->get_settings_for_display();
        ?>
        <section class="ytmp4-faq-section" id="faq">
            <div class="ytmp4-container">
                <?php if (!empty($s['section_title'])) : ?>
                    <div class="ytmp4-section-header">
                        <h2 class="ytmp4-section-title"><?php echo esc_html($s['section_title']); ?></h2>
                        <?php if (!empty($s['section_desc'])) : ?>
                            <p class="ytmp4-section-desc"><?php echo esc_html($s['section_desc']); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <div class="ytmp4-faq-list">
                    <?php 
                    if (!empty($s['faq_list'])) :
                        foreach ($s['faq_list'] as $index => $item) : 
                    ?>
                        <div class="ytmp4-faq-item <?php echo 0 === $index ? 'active' : ''; ?>">
                            <button type="button" class="ytmp4-faq-question" aria-expanded="<?php echo 0 === $index ? 'true' : 'false'; ?>">
                                <span><?php echo esc_html($item['faq_question']); ?></span>
                                <span class="ytmp4-faq-toggle-icon">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"/></svg>
                                </span>
                            </button>
                            <div class="ytmp4-faq-answer">
                                <div class="ytmp4-faq-answer-inner">
                                    <?php echo esc_html($item['faq_answer']); ?>
                                </div>
                            </div>
                        </div>
                    <?php 
                        endforeach;
                    endif; 
                    ?>
                </div>
            </div>
        </section>
        <?php
    }
}
