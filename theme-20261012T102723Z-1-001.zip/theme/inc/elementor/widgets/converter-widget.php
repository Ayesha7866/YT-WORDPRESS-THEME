<?php
/**
 * YTMP4 - Elementor Converter Box Widget
 *
 * @package YTMP4
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('\Elementor\Widget_Base')) {
    return;
}

class YTMP4_Converter_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'ytmp4_converter';
    }

    public function get_title() {
        return esc_html__('YTMP4 Converter Box', 'ytmp4');
    }

    public function get_icon() {
        return 'eicon-youtube';
    }

    public function get_categories() {
        return array('ytmp4-elements');
    }

    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'section_content',
            array(
                'label' => esc_html__('Converter Content', 'ytmp4'),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            )
        );

        $this->add_control(
            'hero_badge',
            array(
                'label'       => esc_html__('Badge Text', 'ytmp4'),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__('Fast & Free Online Converter', 'ytmp4'),
                'placeholder' => esc_html__('Badge text', 'ytmp4'),
            )
        );

        $this->add_control(
            'heading_text',
            array(
                'label'       => esc_html__('Heading (H1)', 'ytmp4'),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__('YouTube to MP4 Converter', 'ytmp4'),
                'placeholder' => esc_html__('Enter main title', 'ytmp4'),
            )
        );

        $this->add_control(
            'subtitle_text',
            array(
                'label'       => esc_html__('Subtitle Text', 'ytmp4'),
                'type'        => \Elementor\Controls_Manager::TEXTAREA,
                'default'     => esc_html__('Convert YouTube videos to MP4 format quickly with a simple, fast and mobile-friendly online converter.', 'ytmp4'),
            )
        );

        $this->add_control(
            'input_placeholder',
            array(
                'label'       => esc_html__('Input Placeholder', 'ytmp4'),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__('Paste YouTube video link here... (e.g. https://youtube.com/watch?v=...)', 'ytmp4'),
            )
        );

        $this->add_control(
            'button_text',
            array(
                'label'       => esc_html__('Convert Button Text', 'ytmp4'),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__('Convert Now', 'ytmp4'),
            )
        );

        $this->add_control(
            'show_tabs',
            array(
                'label'        => esc_html__('Show Format Tabs', 'ytmp4'),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'default'      => 'yes',
                'return_value' => 'yes',
            )
        );

        $this->add_control(
            'show_trust',
            array(
                'label'        => esc_html__('Show Trust Checkmarks', 'ytmp4'),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'default'      => 'yes',
                'return_value' => 'yes',
            )
        );

        $this->end_controls_section();

        // Style Section
        $this->start_controls_section(
            'section_style',
            array(
                'label' => esc_html__('Style & Colors', 'ytmp4'),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'primary_color',
            array(
                'label'     => esc_html__('Button & Accent Color', 'ytmp4'),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .ytmp4-submit-btn' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .ytmp4-tab-btn.active' => 'background: {{VALUE}}; border-color: {{VALUE}};',
                ),
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <div class="ytmp4-hero-section">
            <div class="ytmp4-container">
                <div class="ytmp4-hero-content">
                    <?php if (!empty($settings['hero_badge'])) : ?>
                        <div class="ytmp4-badge-pill">
                            <span class="ytmp4-badge-dot">●</span>
                            <?php echo esc_html($settings['hero_badge']); ?>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($settings['heading_text'])) : ?>
                        <h1 class="ytmp4-hero-title">
                            <?php echo esc_html($settings['heading_text']); ?>
                        </h1>
                    <?php endif; ?>

                    <?php if (!empty($settings['subtitle_text'])) : ?>
                        <p class="ytmp4-hero-subtitle">
                            <?php echo esc_html($settings['subtitle_text']); ?>
                        </p>
                    <?php endif; ?>
                </div>

                <!-- Converter Box Component -->
                <div class="ytmp4-converter-box" id="converter">
                    <?php if ('yes' === $settings['show_tabs']) : ?>
                        <div class="ytmp4-converter-tabs">
                            <button type="button" class="ytmp4-tab-btn active" data-format="mp4">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"/><line x1="7" y1="2" x2="7" y2="22"/><line x1="17" y1="2" x2="17" y2="22"/><line x1="2" y1="12" x2="22" y2="12"/><line x1="2" y1="7" x2="7" y2="7"/><line x1="2" y1="17" x2="7" y2="17"/><line x1="17" y1="17" x2="22" y2="17"/><line x1="17" y1="7" x2="22" y2="7"/></svg>
                                <?php esc_html_e('Video (MP4)', 'ytmp4'); ?>
                            </button>
                            <button type="button" class="ytmp4-tab-btn" data-format="mp3">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>
                                <?php esc_html_e('Audio (MP3)', 'ytmp4'); ?>
                            </button>
                            <button type="button" class="ytmp4-tab-btn" data-format="shorts">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                                <?php esc_html_e('Shorts (HD)', 'ytmp4'); ?>
                            </button>
                            <button type="button" class="ytmp4-tab-btn" data-format="thumbnail">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                                <?php esc_html_e('Thumbnail', 'ytmp4'); ?>
                            </button>
                        </div>
                    <?php endif; ?>

                    <form id="ytmp4-converter-form" class="ytmp4-converter-form">
                        <div class="ytmp4-input-group">
                            <span class="ytmp4-input-icon">
                                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
                            </span>
                            <input 
                                type="url" 
                                id="ytmp4-url-input" 
                                class="ytmp4-url-input" 
                                placeholder="<?php echo esc_attr($settings['input_placeholder']); ?>" 
                                required 
                                autocomplete="off"
                            />
                            <div class="ytmp4-input-controls">
                                <button type="button" id="ytmp4-paste-btn" class="ytmp4-action-icon-btn" title="<?php esc_attr_e('Paste from clipboard', 'ytmp4'); ?>">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                                    <?php esc_html_e('Paste', 'ytmp4'); ?>
                                </button>
                                <button type="button" id="ytmp4-clear-btn" class="ytmp4-action-icon-btn" title="<?php esc_attr_e('Clear input', 'ytmp4'); ?>">
                                    ✕
                                </button>
                            </div>
                        </div>

                        <div class="ytmp4-form-row">
                            <div class="ytmp4-quality-select-wrapper">
                                <select id="ytmp4-quality-select" class="ytmp4-quality-select" aria-label="<?php esc_attr_e('Select Video Quality', 'ytmp4'); ?>">
                                    <option value="1080p"><?php esc_html_e('1080p Full HD (MP4)', 'ytmp4'); ?></option>
                                    <option value="720p"><?php esc_html_e('720p HD (MP4)', 'ytmp4'); ?></option>
                                    <option value="480p"><?php esc_html_e('480p Medium (MP4)', 'ytmp4'); ?></option>
                                    <option value="360p"><?php esc_html_e('360p Standard (MP4)', 'ytmp4'); ?></option>
                                    <option value="320kbps"><?php esc_html_e('320 kbps High Quality (MP3)', 'ytmp4'); ?></option>
                                </select>
                            </div>

                            <button type="submit" id="ytmp4-convert-btn" class="ytmp4-submit-btn">
                                <span><?php echo esc_html($settings['button_text']); ?></span>
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                            </button>
                        </div>

                        <div id="ytmp4-error-box" class="ytmp4-error-box" style="display:none; color:#dc2626; background:#fef2f2; border:1px solid #fecaca; padding:12px; border-radius:8px; font-weight:600; font-size:0.9rem; margin-top:8px;"></div>
                    </form>

                    <!-- Status / Loading Area -->
                    <div id="ytmp4-status-area" class="ytmp4-status-area">
                        <div class="ytmp4-spinner"></div>
                        <div id="ytmp4-status-text" class="ytmp4-status-text"><?php esc_html_e('Processing video link...', 'ytmp4'); ?></div>
                        <div class="ytmp4-progress-bar-bg">
                            <div id="ytmp4-progress-fill" class="ytmp4-progress-bar-fill"></div>
                        </div>
                    </div>

                    <!-- Result Area -->
                    <div id="ytmp4-result-area" class="ytmp4-result-area">
                        <div class="ytmp4-result-header">
                            <div class="ytmp4-result-thumb-wrapper">
                                <img id="ytmp4-result-thumb" class="ytmp4-result-thumb" src="" alt="Thumbnail" />
                                <span id="ytmp4-result-duration" class="ytmp4-duration-badge">00:00</span>
                            </div>
                            <div class="ytmp4-result-meta">
                                <h3 id="ytmp4-result-title" class="ytmp4-result-title"><?php esc_html_e('Video Title', 'ytmp4'); ?></h3>
                                <p id="ytmp4-result-author" class="ytmp4-result-author"><?php esc_html_e('Channel Name', 'ytmp4'); ?></p>
                            </div>
                        </div>

                        <div class="ytmp4-downloads-wrapper">
                            <table class="ytmp4-downloads-table">
                                <thead>
                                    <tr>
                                        <th><?php esc_html_e('Quality', 'ytmp4'); ?></th>
                                        <th><?php esc_html_e('Format', 'ytmp4'); ?></th>
                                        <th><?php esc_html_e('File Size', 'ytmp4'); ?></th>
                                        <th><?php esc_html_e('Action', 'ytmp4'); ?></th>
                                    </tr>
                                </thead>
                                <tbody id="ytmp4-downloads-body">
                                    <!-- Populated by JS -->
                                </tbody>
                            </table>
                        </div>

                        <button type="button" id="ytmp4-reset-btn" class="ytmp4-reset-btn">
                            ← <?php esc_html_e('Convert Another Video', 'ytmp4'); ?>
                        </button>
                    </div>
                </div>

                <?php if ('yes' === $settings['show_trust']) : ?>
                    <div class="ytmp4-hero-trust-row">
                        <div class="ytmp4-trust-item"><span class="ytmp4-trust-icon">✓</span> <?php esc_html_e('100% Free & Unlimited', 'ytmp4'); ?></div>
                        <div class="ytmp4-trust-item"><span class="ytmp4-trust-icon">✓</span> <?php esc_html_e('Up to 4K Ultra HD', 'ytmp4'); ?></div>
                        <div class="ytmp4-trust-item"><span class="ytmp4-trust-icon">✓</span> <?php esc_html_e('No Software Required', 'ytmp4'); ?></div>
                        <div class="ytmp4-trust-item"><span class="ytmp4-trust-icon">✓</span> <?php esc_html_e('Lightning Fast Processing', 'ytmp4'); ?></div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }
}
