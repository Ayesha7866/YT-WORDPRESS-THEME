<?php
/**
 * YTMP4 - Elementor Popular Tools Widget
 *
 * @package YTMP4
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('\Elementor\Widget_Base')) {
    return;
}

class YTMP4_Tools_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'ytmp4_tools';
    }

    public function get_title() {
        return esc_html__('YTMP4 Popular Tools', 'ytmp4');
    }

    public function get_icon() {
        return 'eicon-apps';
    }

    public function get_categories() {
        return array('ytmp4-elements');
    }

    protected function register_controls() {
        $this->start_controls_section(
            'section_tools',
            array(
                'label' => esc_html__('Tools Section', 'ytmp4'),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            )
        );

        $this->add_control(
            'section_title',
            array(
                'label'   => esc_html__('Section Title', 'ytmp4'),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Popular Video Conversion Tools', 'ytmp4'),
            )
        );

        $this->add_control(
            'section_desc',
            array(
                'label'   => esc_html__('Section Subtitle', 'ytmp4'),
                'type'    => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Explore our comprehensive suite of high-speed YouTube downloading and conversion utilities.', 'ytmp4'),
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $s = $this->get_settings_for_display();
        $tools = array(
            array(
                'title' => esc_html__('YouTube MP4 Converter', 'ytmp4'),
                'desc'  => esc_html__('Download video streams in up to 1080p, 2K, and 4K MP4 format.', 'ytmp4'),
                'url'   => home_url('/youtube-to-mp4/'),
                'badge' => 'POPULAR',
                'icon'  => '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"/><line x1="7" y1="2" x2="7" y2="22"/><line x1="17" y1="2" x2="17" y2="22"/><line x1="2" y1="12" x2="22" y2="12"/></svg>'
            ),
            array(
                'title' => esc_html__('YouTube MP3 Converter', 'ytmp4'),
                'desc'  => esc_html__('Extract studio quality 320kbps MP3 audio tracks with lossless sound.', 'ytmp4'),
                'url'   => home_url('/youtube-to-mp3/'),
                'badge' => 'AUDIO HQ',
                'icon'  => '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>'
            ),
            array(
                'title' => esc_html__('YouTube Shorts Downloader', 'ytmp4'),
                'desc'  => esc_html__('Save vertical short videos without watermarks in crisp HD quality.', 'ytmp4'),
                'url'   => home_url('/youtube-shorts-downloader/'),
                'badge' => 'FAST',
                'icon'  => '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>'
            ),
            array(
                'title' => esc_html__('Thumbnail Downloader', 'ytmp4'),
                'desc'  => esc_html__('Download original high-definition YouTube thumbnail images in HD and 4K.', 'ytmp4'),
                'url'   => home_url('/youtube-thumbnail-downloader/'),
                'badge' => 'HD IMAGE',
                'icon'  => '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>'
            ),
            array(
                'title' => esc_html__('Playlist Downloader', 'ytmp4'),
                'desc'  => esc_html__('Batch convert entire YouTube video playlists and music albums at once.', 'ytmp4'),
                'url'   => home_url('/youtube-playlist-downloader/'),
                'badge' => 'BATCH',
                'icon'  => '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>'
            ),
        );
        ?>
        <section class="ytmp4-tools-section" id="tools">
            <div class="ytmp4-container">
                <?php if (!empty($s['section_title'])) : ?>
                    <div class="ytmp4-section-header">
                        <h2 class="ytmp4-section-title"><?php echo esc_html($s['section_title']); ?></h2>
                        <?php if (!empty($s['section_desc'])) : ?>
                            <p class="ytmp4-section-desc"><?php echo esc_html($s['section_desc']); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <div class="ytmp4-tools-grid">
                    <?php foreach ($tools as $tool) : ?>
                        <a href="<?php echo esc_url($tool['url']); ?>" class="ytmp4-tool-card">
                            <span class="ytmp4-tool-badge"><?php echo esc_html($tool['badge']); ?></span>
                            <div class="ytmp4-tool-icon">
                                <?php echo $tool['icon']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                            </div>
                            <h3 class="ytmp4-tool-title"><?php echo esc_html($tool['title']); ?></h3>
                            <p class="ytmp4-tool-desc"><?php echo esc_html($tool['desc']); ?></p>
                            <span class="ytmp4-tool-link-text">
                                <?php esc_html_e('Open Converter', 'ytmp4'); ?> →
                            </span>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
        <?php
    }
}
