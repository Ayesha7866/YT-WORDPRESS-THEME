<?php
/**
 * YTMP4 - Elementor How It Works Widget
 *
 * @package YTMP4
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('\Elementor\Widget_Base')) {
    return;
}

class YTMP4_HowItWorks_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'ytmp4_how_it_works';
    }

    public function get_title() {
        return esc_html__('YTMP4 How It Works', 'ytmp4');
    }

    public function get_icon() {
        return 'eicon-flow';
    }

    public function get_categories() {
        return array('ytmp4-elements');
    }

    protected function register_controls() {
        $this->start_controls_section(
            'section_steps',
            array(
                'label' => esc_html__('Steps Content', 'ytmp4'),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            )
        );

        $this->add_control(
            'section_title',
            array(
                'label'   => esc_html__('Section Title', 'ytmp4'),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('How It Works', 'ytmp4'),
            )
        );

        $this->add_control(
            'section_desc',
            array(
                'label'   => esc_html__('Section Subtitle', 'ytmp4'),
                'type'    => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Convert your favorite YouTube videos into MP4 in 3 simple steps.', 'ytmp4'),
            )
        );

        // Step 1
        $this->add_control(
            'step1_title',
            array(
                'label'   => esc_html__('Step 1 Title', 'ytmp4'),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Paste YouTube URL', 'ytmp4'),
            )
        );
        $this->add_control(
            'step1_desc',
            array(
                'label'   => esc_html__('Step 1 Description', 'ytmp4'),
                'type'    => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Copy the video or Shorts link from YouTube and paste it into the converter search bar above.', 'ytmp4'),
            )
        );

        // Step 2
        $this->add_control(
            'step2_title',
            array(
                'label'   => esc_html__('Step 2 Title', 'ytmp4'),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Choose Format', 'ytmp4'),
            )
        );
        $this->add_control(
            'step2_desc',
            array(
                'label'   => esc_html__('Step 2 Description', 'ytmp4'),
                'type'    => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Select your desired video resolution (1080p, 720p, 480p) or extract MP3 audio and click Convert.', 'ytmp4'),
            )
        );

        // Step 3
        $this->add_control(
            'step3_title',
            array(
                'label'   => esc_html__('Step 3 Title', 'ytmp4'),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Download File', 'ytmp4'),
            )
        );
        $this->add_control(
            'step3_desc',
            array(
                'label'   => esc_html__('Step 3 Description', 'ytmp4'),
                'type'    => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Once conversion completes within moments, click Download to save the file straight to your device.', 'ytmp4'),
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $s = $this->get_settings_for_display();
        ?>
        <section class="ytmp4-how-section" id="how-it-works">
            <div class="ytmp4-container">
                <?php if (!empty($s['section_title'])) : ?>
                    <div class="ytmp4-section-header">
                        <h2 class="ytmp4-section-title"><?php echo esc_html($s['section_title']); ?></h2>
                        <?php if (!empty($s['section_desc'])) : ?>
                            <p class="ytmp4-section-desc"><?php echo esc_html($s['section_desc']); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <div class="ytmp4-steps-grid">
                    <!-- Step 1 -->
                    <div class="ytmp4-step-card">
                        <div class="ytmp4-step-number">1</div>
                        <h3 class="ytmp4-step-title"><?php echo esc_html($s['step1_title']); ?></h3>
                        <p class="ytmp4-step-text"><?php echo esc_html($s['step1_desc']); ?></p>
                    </div>

                    <!-- Step 2 -->
                    <div class="ytmp4-step-card">
                        <div class="ytmp4-step-number">2</div>
                        <h3 class="ytmp4-step-title"><?php echo esc_html($s['step2_title']); ?></h3>
                        <p class="ytmp4-step-text"><?php echo esc_html($s['step2_desc']); ?></p>
                    </div>

                    <!-- Step 3 -->
                    <div class="ytmp4-step-card">
                        <div class="ytmp4-step-number">3</div>
                        <h3 class="ytmp4-step-title"><?php echo esc_html($s['step3_title']); ?></h3>
                        <p class="ytmp4-step-text"><?php echo esc_html($s['step3_desc']); ?></p>
                    </div>
                </div>
            </div>
        </section>
        <?php
    }
}
