<?php
/**
 * YTMP4 - SEO Schema & Breadcrumbs Generator
 *
 * Generates JSON-LD Structured Data for WebApplication, FAQPage,
 * BreadcrumbList, and provides breadcrumb navigation.
 *
 * @package YTMP4
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Render Breadcrumb Navigation
 */
function ytmp4_breadcrumbs() {
    if (is_front_page()) {
        return;
    }

    echo '<nav class="ytmp4-breadcrumbs" aria-label="Breadcrumb">';
    echo '<a href="' . esc_url(home_url('/')) . '">' . esc_html__('Home', 'ytmp4') . '</a>';
    echo '<span class="ytmp4-sep" aria-hidden="true">/</span>';

    if (is_singular()) {
        the_title('<span class="ytmp4-current" aria-current="page">', '</span>');
    } elseif (is_archive()) {
        echo '<span class="ytmp4-current" aria-current="page">' . get_the_archive_title() . '</span>';
    } elseif (is_404()) {
        echo '<span class="ytmp4-current" aria-current="page">' . esc_html__('Page Not Found', 'ytmp4') . '</span>';
    }

    echo '</nav>';
}

/**
 * Output JSON-LD Schemas in Head
 */
function ytmp4_output_seo_schemas() {
    $site_url = esc_url(home_url('/'));
    $site_name = get_bloginfo('name');
    $site_desc = get_bloginfo('description');

    // 1. WebApplication Schema
    $app_schema = array(
        '@context' => 'https://schema.org',
        '@type' => 'WebApplication',
        'name' => 'YTMP4 - YouTube to MP4 Converter',
        'url' => $site_url,
        'description' => 'Fast, free, and secure online YouTube to MP4 video converter and downloader supporting 1080p, HD, 4K, and MP3 audio.',
        'applicationCategory' => 'MultimediaApplication',
        'operatingSystem' => 'All (Windows, macOS, Linux, Android, iOS)',
        'browserRequirements' => 'Requires JavaScript. Requires HTML5.',
        'offers' => array(
            '@type' => 'Offer',
            'price' => '0',
            'priceCurrency' => 'USD'
        )
    );

    echo '<script type="application/ld+json">' . wp_json_encode($app_schema, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . '</script>' . "\n";

    // 2. FAQ Schema for Homepage and FAQ pages
    $faq_data = ytmp4_get_default_faqs();
    if (!empty($faq_data)) {
        $faq_schema = array(
            '@context' => 'https://schema.org',
            '@type' => 'FAQPage',
            'mainEntity' => array()
        );

        foreach ($faq_data as $faq) {
            $faq_schema['mainEntity'][] = array(
                '@type' => 'Question',
                'name' => $faq['q'],
                'acceptedAnswer' => array(
                    '@type' => 'Answer',
                    'text' => $faq['a']
                )
            );
        }

        echo '<script type="application/ld+json">' . wp_json_encode($faq_schema, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . '</script>' . "\n";
    }

    // 3. BreadcrumbList Schema on non-front pages
    if (!is_front_page()) {
        $crumbs = array(
            '@context' => 'https://schema.org',
            '@type' => 'BreadcrumbList',
            'itemListElement' => array(
                array(
                    '@type' => 'ListItem',
                    'position' => 1,
                    'name' => 'Home',
                    'item' => $site_url
                ),
                array(
                    '@type' => 'ListItem',
                    'position' => 2,
                    'name' => get_the_title(),
                    'item' => esc_url(get_permalink())
                )
            )
        );

        echo '<script type="application/ld+json">' . wp_json_encode($crumbs, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . '</script>' . "\n";
    }
}
add_action('wp_head', 'ytmp4_output_seo_schemas', 1);

/**
 * Default FAQ Items (Reusable across schema and frontend templates)
 */
function ytmp4_get_default_faqs() {
    return array(
        array(
            'q' => esc_html__('What is YouTube to MP4 converter?', 'ytmp4'),
            'a' => esc_html__('A YouTube to MP4 converter is an online tool that allows you to convert and download videos from YouTube into standard MP4 video files. This enables you to store and watch your favorite video clips, tutorials, music videos, and educational lectures offline on any device without an active internet connection.', 'ytmp4')
        ),
        array(
            'q' => esc_html__('How can I convert YouTube videos to MP4?', 'ytmp4'),
            'a' => esc_html__('Converting videos is simple with YTMP4: 1. Copy the URL of your chosen YouTube video. 2. Paste the URL into our input box above. 3. Select your desired MP4 quality (1080p, 720p, or 480p) and click "Convert Now". Once processed in seconds, click "Download" to save your file.', 'ytmp4')
        ),
        array(
            'q' => esc_html__('Is this converter mobile friendly?', 'ytmp4'),
            'a' => esc_html__('Yes! YTMP4 is 100% responsive and mobile-optimized. You can use it smoothly on Android smartphones and tablets using Chrome or Firefox, as well as on iPhone and iPad running Safari with iOS 13+ without needing any third-party apps.', 'ytmp4')
        ),
        array(
            'q' => esc_html__('Which formats are supported?', 'ytmp4'),
            'a' => esc_html__('YTMP4 supports multiple high-definition video and audio formats, including MP4 (360p, 480p, 720p HD, 1080p Full HD, 4K Ultra HD), MP3 audio (128kbps, 192kbps, 256kbps, 320kbps HQ), YouTube Shorts, and high-resolution thumbnail images.', 'ytmp4')
        )
    );
}
