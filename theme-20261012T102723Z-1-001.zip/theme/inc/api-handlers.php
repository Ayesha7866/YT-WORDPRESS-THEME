<?php
/**
 * YTMP4 - API Ready Handlers & AJAX Integration
 *
 * Provides extensible hooks, REST API endpoints, and WP-AJAX handlers
 * for connecting future video processing servers, RapidAPI, or yt-dlp backends.
 *
 * @package YTMP4
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register REST API Endpoints
 */
function ytmp4_register_rest_routes() {
    register_rest_route('ytmp4/v1', '/convert', array(
        'methods'             => array('GET', 'POST'),
        'callback'            => 'ytmp4_rest_convert_handler',
        'permission_callback' => '__return_true',
    ));
}
add_action('rest_api_init', 'ytmp4_register_rest_routes');

/**
 * REST API Callback
 */
function ytmp4_rest_convert_handler($request) {
    $url     = sanitize_text_field($request->get_param('url'));
    $format  = sanitize_text_field($request->get_param('format')) ?: 'mp4';
    $quality = sanitize_text_field($request->get_param('quality')) ?: '1080p';

    $result = ytmp4_process_conversion_request($url, $format, $quality);

    if (is_wp_error($result)) {
        return new WP_REST_Response(array(
            'success' => false,
            'message' => $result->get_error_message()
        ), 400);
    }

    return new WP_REST_Response(array(
        'success' => true,
        'data'    => $result
    ), 200);
}

/**
 * WP AJAX Handler (for logged-in & non-logged-in users)
 */
function ytmp4_ajax_convert_video() {
    check_ajax_referer('ytmp4_converter_nonce', 'nonce', false);

    $url     = isset($_POST['url']) ? sanitize_text_field(wp_unslash($_POST['url'])) : '';
    $format  = isset($_POST['format']) ? sanitize_text_field(wp_unslash($_POST['format'])) : 'mp4';
    $quality = isset($_POST['quality']) ? sanitize_text_field(wp_unslash($_POST['quality'])) : '1080p';

    $result = ytmp4_process_conversion_request($url, $format, $quality);

    if (is_wp_error($result)) {
        wp_send_json_error(array('message' => $result->get_error_message()));
    } else {
        wp_send_json_success($result);
    }
}
add_action('wp_ajax_ytmp4_convert_video', 'ytmp4_ajax_convert_video');
add_action('wp_ajax_nopriv_ytmp4_convert_video', 'ytmp4_ajax_convert_video');

/**
 * Extensible Conversion Request Processor
 *
 * Designed with WordPress filters so a downstream plugin (or custom functions.php)
 * can attach real cloud video processing (e.g. RapidAPI, yt-dlp API, Cobalt, etc.)
 */
function ytmp4_process_conversion_request($url, $format = 'mp4', $quality = '1080p') {
    if (empty($url)) {
        return new WP_Error('empty_url', __('Please provide a YouTube video URL.', 'ytmp4'));
    }

    // Extract Video ID
    preg_match('/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/|youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/', $url, $matches);
    $video_id = !empty($matches[1]) ? $matches[1] : '';

    if (empty($video_id)) {
        return new WP_Error('invalid_url', __('Invalid YouTube video link. Please verify the URL.', 'ytmp4'));
    }

    // Fire action before processing
    do_action('ytmp4_before_conversion', $video_id, $url, $format, $quality);

    // Default structure ready for API plugins to populate
    $response_data = array(
        'videoId'   => $video_id,
        'title'     => 'YouTube Video (' . strtoupper($format) . ' - ' . esc_html($quality) . ')',
        'author'    => 'YouTube Creator',
        'duration'  => '04:12',
        'thumbnail' => 'https://img.youtube.com/vi/' . $video_id . '/hqdefault.jpg',
        'format'    => $format,
        'quality'   => $quality,
        'downloads' => array(
            array('quality' => '1080p Full HD', 'format' => 'MP4', 'size' => '62.4 MB', 'url' => '#'),
            array('quality' => '720p HD',      'format' => 'MP4', 'size' => '36.8 MB', 'url' => '#'),
            array('quality' => '480p Medium',  'format' => 'MP4', 'size' => '20.1 MB', 'url' => '#'),
            array('quality' => '360p Standard','format' => 'MP4', 'size' => '12.6 MB', 'url' => '#'),
            array('quality' => '320kbps Audio','format' => 'MP3', 'size' => '9.5 MB',  'url' => '#'),
        )
    );

    /**
     * Filter to allow real converter plugins to supply genuine video streams
     *
     * Example usage in a future plugin:
     * add_filter('ytmp4_convert_api_response', function($data, $video_id, $url, $format) {
     *     $real_api_data = my_custom_rapidapi_fetch($video_id);
     *     return $real_api_data;
     * }, 10, 4);
     */
    return apply_filters('ytmp4_convert_api_response', $response_data, $video_id, $url, $format, $quality);
}
