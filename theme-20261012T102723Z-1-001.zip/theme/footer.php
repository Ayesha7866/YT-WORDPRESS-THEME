<?php
/**
 * YTMP4 - Footer Template
 *
 * @package YTMP4
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
</main><!-- #primary -->

<footer class="ytmp4-footer" id="site-footer">
    <div class="ytmp4-container">
        <div class="ytmp4-footer-grid">
            <!-- Brand Column -->
            <div class="ytmp4-footer-brand">
                <a href="<?php echo esc_url(home_url('/')); ?>" class="ytmp4-logo-link">
                    <img 
                        src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/logo.svg'); ?>" 
                        alt="<?php echo esc_attr(get_bloginfo('name', 'display')); ?>" 
                        class="ytmp4-logo-img"
                        width="180"
                        height="38"
                    />
                </a>
                <p>
                    <?php esc_html_e('YTMP4 is a free, high-speed online video converter tool allowing users to convert YouTube videos to MP4 and MP3 format in seconds with high quality.', 'ytmp4'); ?>
                </p>
            </div>

            <!-- Column 1: Video Tools -->
            <div class="ytmp4-footer-col">
                <h4><?php esc_html_e('Video Converters', 'ytmp4'); ?></h4>
                <ul class="ytmp4-footer-links">
                    <li><a href="<?php echo esc_url(home_url('/youtube-to-mp4/')); ?>"><?php esc_html_e('YouTube To MP4', 'ytmp4'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/convert-youtube-to-mp4/')); ?>"><?php esc_html_e('Convert YouTube To MP4', 'ytmp4'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/youtube-video-converter/')); ?>"><?php esc_html_e('YouTube Video Converter', 'ytmp4'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/youtube-shorts-downloader/')); ?>"><?php esc_html_e('Shorts Downloader', 'ytmp4'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/youtube-thumbnail-downloader/')); ?>"><?php esc_html_e('Thumbnail Downloader', 'ytmp4'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/youtube-playlist-downloader/')); ?>"><?php esc_html_e('Playlist Downloader', 'ytmp4'); ?></a></li>
                </ul>
            </div>

            <!-- Column 2: Resolutions & Devices -->
            <div class="ytmp4-footer-col">
                <h4><?php esc_html_e('HD & Mobile Formats', 'ytmp4'); ?></h4>
                <ul class="ytmp4-footer-links">
                    <li><a href="<?php echo esc_url(home_url('/youtube-to-mp4-1080p/')); ?>"><?php esc_html_e('YouTube To MP4 1080p', 'ytmp4'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/youtube-to-mp4-hd/')); ?>"><?php esc_html_e('YouTube To MP4 HD', 'ytmp4'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/youtube-to-mp4-4k/')); ?>"><?php esc_html_e('YouTube To MP4 4K', 'ytmp4'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/youtube-to-mp4-android/')); ?>"><?php esc_html_e('YouTube To MP4 Android', 'ytmp4'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/youtube-to-mp4-iphone/')); ?>"><?php esc_html_e('YouTube To MP4 iPhone', 'ytmp4'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/youtube-to-mp3/')); ?>"><?php esc_html_e('YouTube MP3 Converter', 'ytmp4'); ?></a></li>
                </ul>
            </div>

            <!-- Column 3: Company & Legal -->
            <div class="ytmp4-footer-col">
                <h4><?php esc_html_e('Information & Legal', 'ytmp4'); ?></h4>
                <ul class="ytmp4-footer-links">
                    <li><a href="<?php echo esc_url(home_url('/how-it-works/')); ?>"><?php esc_html_e('How It Works', 'ytmp4'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/faq/')); ?>"><?php esc_html_e('FAQ', 'ytmp4'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/contact/')); ?>"><?php esc_html_e('Contact', 'ytmp4'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/privacy-policy/')); ?>"><?php esc_html_e('Privacy Policy', 'ytmp4'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/terms-of-service/')); ?>"><?php esc_html_e('Terms Of Service', 'ytmp4'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/dmca/')); ?>"><?php esc_html_e('DMCA Policy', 'ytmp4'); ?></a></li>
                </ul>
            </div>
        </div>

        <div class="ytmp4-footer-bottom">
            <p>
                <?php 
                echo wp_kses_post(get_theme_mod('ytmp4_footer_copyright', sprintf(__('© %s YTMP4. All rights reserved. Fast online video conversion tools.', 'ytmp4'), date('Y')))); 
                ?>
            </p>
            <p class="ytmp4-disclaimer">
                <?php esc_html_e('Disclaimer: YTMP4 does not host or store any video files on its servers. All videos and multimedia assets remain property of their respective copyright owners. YTMP4 is an independent web utility not affiliated with YouTube or Google LLC.', 'ytmp4'); ?>
            </p>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
