<?php
/**
 * YTMP4 - Single Post Template
 *
 * @package YTMP4
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<div class="ytmp4-post-header" style="background:#ffffff; border-bottom:1px solid #e2e8f0; padding:48px 0 32px; text-align:center;">
    <div class="ytmp4-container">
        <?php ytmp4_breadcrumbs(); ?>
        <h1 class="ytmp4-hero-title">
            <?php the_title(); ?>
        </h1>
        <div style="color:#64748b; font-size:0.9rem; font-weight:600; display:flex; justify-content:center; gap:16px;">
            <span><?php echo esc_html(get_the_date()); ?></span>
            <span>•</span>
            <span><?php echo esc_html(get_the_author()); ?></span>
        </div>
    </div>
</div>

<div class="ytmp4-post-body" style="padding: 48px 0;">
    <div class="ytmp4-container">
        <article class="ytmp4-seo-article" style="margin: 0 auto;">
            <?php
            if (has_post_thumbnail()) {
                the_post_thumbnail('large', array('style' => 'border-radius:12px; margin-bottom:28px; width:100%; height:auto;'));
            }

            while (have_posts()) :
                the_post();
                the_content();

                wp_link_pages(array(
                    'before' => '<div class="page-links">' . esc_html__('Pages:', 'ytmp4'),
                    'after'  => '</div>',
                ));
            endwhile;
            ?>
        </article>
    </div>
</div>

<?php
get_footer();
