<?php
/**
 * YTMP4 - 404 Not Found Template
 *
 * @package YTMP4
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<div class="ytmp4-404-section" style="padding: 72px 0; text-align:center;">
    <div class="ytmp4-container">
        <div class="ytmp4-badge-pill" style="color:#ef4444; border-color:#fecaca; background:#fef2f2;">
            <?php esc_html_e('404 Error — Page Not Found', 'ytmp4'); ?>
        </div>

        <h1 class="ytmp4-hero-title" style="margin-top: 16px;">
            <?php esc_html_e('Oops! That page seems to be missing.', 'ytmp4'); ?>
        </h1>

        <p class="ytmp4-hero-subtitle" style="margin-bottom: 40px;">
            <?php esc_html_e('The link you followed may be broken or moved. You can convert your YouTube video directly using our tool below:', 'ytmp4'); ?>
        </p>

        <!-- Provide Immediate Utility: The Converter Box -->
        <?php get_template_part('template-parts/converter-box'); ?>

        <div style="margin-top: 48px;">
            <a href="<?php echo esc_url(home_url('/')); ?>" class="ytmp4-btn-primary">
                ← <?php esc_html_e('Back to Homepage', 'ytmp4'); ?>
            </a>
        </div>
    </div>
</div>

<?php
get_footer();
