=== YTMP4 - YouTube to MP4 Converter WordPress Theme ===
Contributors: YTMP4 Team
Tags: youtube converter, video downloader, mp4 converter, elementor, programmatic seo
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A premium, ultra-fast, SEO-first WordPress theme built specifically for YouTube to MP4 video converter websites.

== Description ==

YTMP4 is an online utility theme designed for modern video conversion platforms. Built with a clean SaaS utility aesthetic (clean white backgrounds, soft card shadows, modern blue gradient accents, and mobile-first responsiveness), YTMP4 delivers instant speed and high conversion rates.

Key Features:
- 100% Real WordPress Theme: Standard compliant, no external dependencies, uploadable as a ZIP directly from the WordPress dashboard.
- Elementor Compatible: Includes 8 custom Elementor widgets in the "YTMP4 Converter Elements" category for complete drag-and-drop visual editing.
- API-Ready Converter Frontend: Built with structured CSS IDs/classes, interactive loading feedback, download stream tables, and WordPress AJAX/REST endpoints ready for future backend services (RapidAPI, yt-dlp, Cobalt).
- 19+ Programmatic SEO Landing Pages: Includes a 1-click generator in the admin panel (Appearance > YTMP4 SEO Pages) to instantly provision all 19 landing pages.
- JSON-LD Structured Data: Built-in WebApplication, FAQPage, and BreadcrumbList schemas for top rankings in Google.
- Core Web Vitals Friendly: Pure lightweight CSS and vanilla JavaScript with zero jQuery dependency for the converter.

== Included 19 SEO Landing Pages ==
1. Homepage: /
2. YouTube To MP4 Converter: /youtube-to-mp4/
3. Convert YouTube To MP4: /convert-youtube-to-mp4/
4. YouTube Video Converter: /youtube-video-converter/
5. YouTube MP3 Converter: /youtube-to-mp3/
6. YouTube Shorts Downloader: /youtube-shorts-downloader/
7. YouTube Thumbnail Downloader: /youtube-thumbnail-downloader/
8. YouTube Playlist Downloader: /youtube-playlist-downloader/
9. YouTube To MP4 1080p: /youtube-to-mp4-1080p/
10. YouTube To MP4 HD: /youtube-to-mp4-hd/
11. YouTube To MP4 4K: /youtube-to-mp4-4k/
12. YouTube To MP4 Android: /youtube-to-mp4-android/
13. YouTube To MP4 iPhone: /youtube-to-mp4-iphone/
14. How It Works: /how-it-works/
15. FAQ: /faq/
16. Contact: /contact/
17. Privacy Policy: /privacy-policy/
18. Terms Of Service: /terms-of-service/
19. DMCA: /dmca/

== Installation ==
1. Download the `ytmp4-theme.zip` package.
2. In your WordPress admin, navigate to Appearance > Themes > Add New.
3. Click "Upload Theme" and select `ytmp4-theme.zip`.
4. Click "Install Now" and then "Activate".
5. Upon activation, all 19 SEO landing pages and navigation menus are automatically provisioned. You can also re-sync them anytime from Appearance > YTMP4 SEO Pages.

== Elementor Visual Editing ==
1. Edit any page and click "Edit with Elementor".
2. In the widget drawer, scroll to "YTMP4 Converter Elements".
3. Drag and drop any of the 8 widgets:
   - YTMP4 Converter Box
   - YTMP4 Feature Cards
   - YTMP4 How It Works
   - YTMP4 Popular Tools
   - YTMP4 Why Choose Us
   - YTMP4 Device Compatibility
   - YTMP4 FAQ Accordion
   - YTMP4 Call to Action Banner
4. Customize titles, subtitles, placeholders, colors, and button links visually.

== Future API Integration ==
The frontend is already configured to dispatch JavaScript events and listen to WordPress REST/AJAX hooks:
- Filter hook: `apply_filters('ytmp4_convert_api_response', $data, $video_id, $url, $format, $quality);`
- Custom JS Events: `document.addEventListener('ytmp4:convert_start', function(e) { ... });`
- REST Endpoint: `POST /wp-json/ytmp4/v1/convert`
- AJAX Action: `wp_ajax_ytmp4_convert_video` and `wp_ajax_nopriv_ytmp4_convert_video`
