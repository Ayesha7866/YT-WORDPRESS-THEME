<?php
/**
 * YTMP4 - Standard Page Template
 *
 * @package YTMP4
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<div class="ytmp4-page-header" style="background:#ffffff; border-bottom:1px solid #e2e8f0; padding:48px 0 32px; text-align:center;">
    <div class="ytmp4-container">
        <?php ytmp4_breadcrumbs(); ?>
        <h1 class="ytmp4-hero-title" style="margin-bottom: 0;">
            <?php the_title(); ?>
        </h1>
    </div>
</div>

<div class="ytmp4-page-body" style="padding: 48px 0;">
    <div class="ytmp4-container">
        <article class="ytmp4-seo-article" style="margin: 0 auto;">
            <?php
            while (have_posts()) :
                the_post();
                the_content();

                wp_link_pages(array(
                    'before' => '<div class="page-links">' . esc_html__('Pages:', 'ytmp4'),
                    'after'  => '</div>',
                ));
            endwhile;
            ?>
        </article>
    </div>
</div>

<?php
get_footer();
