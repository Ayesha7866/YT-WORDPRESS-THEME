<?php
/**
 * Template Name: YTMP4 SEO Converter Landing Page
 * Description: Programmatic SEO landing page template supporting custom H1, subtitle, converter box, benefits, how it works, and FAQs.
 *
 * @package YTMP4
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();

$page_id = get_the_ID();
$custom_h1 = get_post_meta($page_id, 'ytmp4_custom_h1', true);
if (empty($custom_h1)) {
    $custom_h1 = get_the_title();
}

$custom_subtitle = get_post_meta($page_id, 'ytmp4_custom_subtitle', true);
if (empty($custom_subtitle)) {
    $custom_subtitle = sprintf(__('Fast, reliable, and secure online YouTube converter tool for %s.', 'ytmp4'), get_the_title());
}

$target_format = get_post_meta($page_id, 'ytmp4_target_format', true) ?: 'mp4';
?>

<div class="ytmp4-landing-hero">
    <div class="ytmp4-container">
        <!-- Breadcrumbs Navigation -->
        <?php ytmp4_breadcrumbs(); ?>

        <div class="ytmp4-hero-content" style="margin-bottom: 32px;">
            <div class="ytmp4-badge-pill">
                <span>●</span> <?php echo esc_html(strtoupper($target_format)); ?> <?php esc_html_e('Converter', 'ytmp4'); ?>
            </div>
            
            <h1 class="ytmp4-hero-title">
                <?php echo esc_html($custom_h1); ?>
            </h1>

            <p class="ytmp4-hero-subtitle">
                <?php echo esc_html($custom_subtitle); ?>
            </p>
        </div>

        <!-- Embedded Converter Box Component -->
        <?php get_template_part('template-parts/converter-box'); ?>

        <div class="ytmp4-hero-trust-row">
            <div class="ytmp4-trust-item"><span class="ytmp4-trust-icon">✓</span> <?php esc_html_e('100% Free & Unlimited', 'ytmp4'); ?></div>
            <div class="ytmp4-trust-item"><span class="ytmp4-trust-icon">✓</span> <?php esc_html_e('No Software Required', 'ytmp4'); ?></div>
            <div class="ytmp4-trust-item"><span class="ytmp4-trust-icon">✓</span> <?php esc_html_e('High Bitrate Speed', 'ytmp4'); ?></div>
        </div>
    </div>
</div>

<!-- SEO Longform Content / Benefits & Guide -->
<section class="ytmp4-seo-article-section">
    <div class="ytmp4-container">
        <article class="ytmp4-seo-article">
            <?php 
            while (have_posts()) : 
                the_post(); 
                the_content(); 
            endwhile; 
            ?>
        </article>
    </div>
</section>

<!-- Reusable How It Works Section -->
<?php get_template_part('template-parts/how-it-works'); ?>

<!-- Reusable Related Tools Section -->
<?php get_template_part('template-parts/tools-section'); ?>

<!-- Device Compatibility -->
<?php get_template_part('template-parts/devices-section'); ?>

<!-- Reusable FAQ Accordion -->
<?php get_template_part('template-parts/faq-section'); ?>

<!-- Reusable Final Call to Action -->
<?php get_template_part('template-parts/cta-section'); ?>

<?php
get_footer();
